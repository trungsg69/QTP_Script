# ========== User guide of Download_Overlay script ========== #

I. Data pool information:

 1. Global sheet: global information
   + iSTART_ROW: (Start iteration), The first line will be run in script.
   + iFINISH_ROW: (End iteration), The last line will be run in script.
   + TimeOut: This value is time limit when script download a file ( 5 x 100 = 500 seconds).
   + AccessToDoc: Check right to access document (default is true).
   + TestDir: The location is stored download files and configuration files.
   + SERV: The server link is run web application.
   + PORT: The port is run web application.
   + LOGIN: User account is used to login web application.
   + PASSWORD: Password account is used to login web application.
   +TestType: This value is defined the way which script will run.
   + Printer : Name of PDF printer is used to print document.
   + FileName: Name of document is saved by PDF printer.
   + Multi: The value is true / false: thi value is only applied for Download action (it is not used for DownloadU3D action).
      -  If this value is true, script will add many document into Compile List, and then script download them from CL.
      -  If this value is false, script will add one document into Compile List, and then script download one from CL. (one by one)
   + RemoteDir: The location in server where store configuration files.
   + EIDToolsDir: The location in server where store EID tools files.
   + sPathTo_psftp: The path point to psftp.exe in local machine.
   + User1: reference to line number of AccountInfo sheet (select account which is used to login server to get configuration files)
   + User2: reference to line number of AccountInfo sheet (select account which is used to login server to get EID tools file)
   + DBConn: reference to line number of DBWork sheet (select connection string which is used to log in DB)
   + RunLine: The value store the line number which will be run in Global sheet. Ex: If RunLine is "2", script will get values of line 2 in Global sheet and execute it.

 2. Download and DownloadU3D sheet: information of document
   + TC: Test case number.
   + DOC_CTGR: Category of document.
   + DOC_NUMBER: Name of document.
   + PARTTYPE:
   + CURRENT:
   + TYPE: Type of document.
   + VOLUME: 
   + CAGE:
   + DASH:
   + REISSUE:
   + DR_OWNER:
   + PROJECT:
   + REV: Revision of document.
   + PARTIAL: Find with partial condition or not (TRUE/FALSE).
   + EXPORT_JUR: 
   + SENS_LEVEL:
   + PROPRIETARY_INF:
   + EXTERNAL: External user or internal user.
   + CustomerCode: Customer code of Overlay user.
   + CustomerCodeN: Customer of Non Overlay user.
   + EOS1: Overlay statement.
   + PropertyInd: Document has Boeing priority or not (Y/N).

 3. DBWork sheet: information of database
   + ConnectionString: connection string of Database server.
   + SQL: SQL statement.

 4. AccountInfo sheet: information of accounts which are used to login server by SSH.
   + SERV: Server host link.
   + USER: Username of SSH account.
   + PASSWORD: Password of SSH account.
    - Notes: 
	a. Currently, script will these account to copy files from server to local machine.
	b. Checked with Narcissus server, port 7771 and Ochid server, port 7771.

II. How to run script:

   + Set values in Global sheet:

      - Runline: Select the line number will be run in Global sheet.
      - iSTART_ROW: Select the first line of each action will be run test.
      - iFINISH_ROW: Select the last line of each action will be run test.
      - Multi: Add each document (FALSE) or add many document (TRUE) before script download document. This value is only applied for Download action.
      - TestType: Select the way to run test.

	+ Download acction has 4 test types value:
	   a. TestType = 1 : Dowload from Compile List with Overlay Statement.
	   b. TestType = 2 : Dowload from Compile List with Non Overlay Statement.
	   c. TestType = 3 : Change Non Overlay Code to Overlay Code.
	   d. TestType = 4 : Change Overlay Code to Non Overlay Code.

	+ DownloadU3D acction has 2 test types value:
	   a. TestType = 1 : Dowload U3D from Compile List with Overlay Statement.
	   b. TestType = 2 : Dowload U3D from View  window (Save A Copy).

  + Download sheet store these test cases for normal document (not U3D document).
  + DownloadU3D sheet store these test cases for U3D document.
  + Global information will be got from Global sheet (the line is selected corresponding to value of RunLine).
  + Script will execute these test data from iSTART_ROW to iFINISH_ROW in data pool. 
  + These features will be tested:
	1. Check dummy image
	2. Check Overlay / Non-Overlay information
	3. Check 3D document
	     3.1 Check Linearization
	     3.2 Check Uage Rights filter
	     3.1 Check EID tools version
	