#!/bin/bash

# Specify java
JAVA=/usr/java5/jre/bin/java

# Specify SSL certificates
TRUST_STORE_CERT_FILE=./ssl/cacerts
TRUST_STORE_AUTH_FILE=./ssl/cacerts.auth
KEY_STORE_CERT_FILE=./ssl/beagle.p12
KEY_STORE_AUTH_FILE=./ssl/beagle.auth
KEY_STORE_TYPE=pkcs12

# Set application lib directory
APP_LIB=./lib

# prepare internal variables - do not change
CP=.:$APP_LIB
CP=$CP:$APP_LIB/activation.jar
CP=$CP:$APP_LIB/axis.jar
CP=$CP:$APP_LIB/commons-cli-1.0.jar
CP=$CP:$APP_LIB/commons-discovery-0.2.jar
CP=$CP:$APP_LIB/commons-logging-1.0.4.jar
CP=$CP:$APP_LIB/jaxrpc.jar
CP=$CP:$APP_LIB/log4j-1.2.8.jar
CP=$CP:$APP_LIB/mail.jar
CP=$CP:$APP_LIB/saaj.jar
CP=$CP:$APP_LIB/test_search.jar
CP=$CP:$APP_LIB/wsdl4j-1.5.1.jar
CP=$CP:$APP_LIB/utils.jar

# prepare java options
OPTIONS="-Dtrust.store.file=${TRUST_STORE_CERT_FILE}"
OPTIONS="${OPTIONS} -Dtrust.store.auth.file=${TRUST_STORE_AUTH_FILE}"
OPTIONS="${OPTIONS} -Dkey.store.file=${KEY_STORE_CERT_FILE}"
OPTIONS="${OPTIONS} -Dkey.store.auth.file=${KEY_STORE_AUTH_FILE}"
OPTIONS="${OPTIONS} -Dkey.store.type=${KEY_STORE_TYPE}"

OPTIONS="${OPTIONS} -Djava.protocol.handler.pkgs=com.sun.net.ssl.internal.www.protocol|com.ibm.net.ssl.www2.protocol"

# Internal search
$JAVA -classpath $CP $OPTIONS com.boeing.redars.searchclient.AutomatedInternalSearchDocuments $*
