/*
 * @(#)SearchResultFormatException.java  1.0
 *
 * Copyright (c) 2006 The Boeing Company All rights reserved.
 */

package com.boeing.redars.searchclient;

/**
 * @author Pavel Kozlov
 * @version 1.0
 */
public class SearchResultFormatException extends Exception {

    public SearchResultFormatException(String msg) {
        super(msg);
    }

    public SearchResultFormatException(Throwable t) {
        super(t);
    }
}
