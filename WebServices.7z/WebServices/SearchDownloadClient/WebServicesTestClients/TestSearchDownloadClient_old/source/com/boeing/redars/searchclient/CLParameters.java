/*
 * @(#)CLParameters.java
 *
 * Copyright (c) 2006 The Boeing Company. All Rights Reserved.
 */

package com.boeing.redars.searchclient;

import com.boeing.redars.commandlineparser.common.CommandLineParametersBase;

/**
 * This class extends base command line parser for contain additional
 * command line parameters
 *
 * @author Pavel Kozlov
 * @version 1.0
 */
public class CLParameters extends CommandLineParametersBase {

    /**
     * This constant represents <code>ALL FILE MAPPING COLLECTION</code>
     * directive value.
     */
    public static final String COLLECT_ALL_FILE_MAPPING = "ALL";

    /**
     * This constant represents <code>RENAMED FILE MAPPING COLLECTION</code>
     * directive value.
     */
    public static final String COLLECT_RENAMED_FILE_MAPPING = "RENAMED";

    /**
     * Flag for download, if it is true, than download will be called
     */
    private boolean m_download = false;

    /**
     * Name of directory, where download files will be stored
     */
    private String m_downloadDir = null;

    /**
     * <code><b>metaInfoDirective</b></code> property represents marker of
     * downloaded files mapping collection type.
     */
    private String m_metaInfoDirective = null;

    /**
     * <code><b>metaInfoFileName</b></code> property represents name of file
     * to store downloaded files mapping.
     */
    private String m_metaInfoFileName = null;
    /**
     * if <code>true</code> skip LiveCycle call during file download.
     */
    private boolean m_bypassLiveCycle = false;

    /**
     * Getter for download flag
     * @return boolean value
     */
    public boolean isDownload() {
        return m_download;
    }

    /**
     * Setter for download flag
     * @param download
     */
    public void setDownload(boolean download) {
        m_download = download;
    }

    /**
     * Getter for download directory name
     * @return string value
     */
    public String getDownloadDir() {
        return m_downloadDir;
    }

    /**
     * Setter for download directory name
     * @param downloadDir
     */
    public void setDownloadDir(String downloadDir) {
        m_downloadDir = downloadDir;
    }

    /**
     * Getter for <code><b>metaInfoDirective</b></code> property.
     *
     * @return String represented value
     */
    public String getMetaInfoDirective() {
        return m_metaInfoDirective;
    }

    /**
     * Setter for <code><b>metaInfoDirective</b></code> property.
     *
     * @param metaInfoDirective String represented value
     */
    public void setMetaInfoDirective(String metaInfoDirective) {
        m_metaInfoDirective = metaInfoDirective;
    }

    /**
     * Getter for <code><b>metaInfoFileName</b></code> property.
     *
     * @return String represented value
     */
    public String getMetaInfoFileName() {
        return m_metaInfoFileName;
    }

    /**
     * Setter for <code><b>metaInfoFileName</b></code> property.
     *
     * @param metaInfoFileName String represented value
     */
    public void setMetaInfoFileName(String metaInfoFileName) {
        m_metaInfoFileName = metaInfoFileName;
    }

    /**
     * Returns <code>true</code> if need skip LiveCycle calls during file
     * download
     *
     * @return <code>true</code> if need skip LiveCycle calls during file
     * download
     */
    public boolean isBypassLiveCycle() {
        return m_bypassLiveCycle;
    }

    /**
     * Sets <code>bypassLiveCycle</code> flag
     *
     * @param bypassLiveCycle If <code>true</code> then need skip LiveCycle
     * calls during file
     */
    public void setBypassLiveCycle(boolean bypassLiveCycle) {
        m_bypassLiveCycle = bypassLiveCycle;
    }
}
