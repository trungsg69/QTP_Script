/*
 * @(#)SearchDownloadConstants.java  1.0
 *
 * Copyright (c) 2006 The Boeing Company All rights reserved.
 */

package com.boeing.redars.searchclient;

import com.boeing.redars.commandlineparser.config.CommandLineConstants;

/**
 * This interface contains constants are used by application
 *
 * @author Pavel Kozlov
 * @version 1.0
 */
public interface SearchDownloadConstants extends CommandLineConstants{

    /*
    * Name of command line parameter for enabling download
    */
    public static String DOWNLOAD_FLAG = "download";

    /*
     * Name of command line parameter for setting directory for download
     */
    public static String DOWNLOAD_DIR = "download_dir";

    /*
     * Description of command line parameter "-download_dir"
     */
    public static String DOWNLOAD_DIR_DESK = "download_dir_name";

    /**
     * Name of command line parameter for setting meta-info file name
     */
    public static String META_INFO_FILE_NAME_PARAM = "meta_info_file";

    /**
     * Description of command line parameter <b>-meta_info_file"</b>
     */
    public static String META_INFO_FILE_NAME_PARAM_DESC = "meta_info_file_name";

    /**
     * Name of command line parameter for setting type of collection
     * of downloaded files meta-info.
     */
    public static String COLLECT_META_INFO_DIRECTIVE_PARAM = "meta_info";

    /**
     * Description of command line parameter <b>-meta_info"</b>
     */
    public static String COLLECT_META_INFO_DIRECTIVE_PARAM_DESC = (
        "meta_info_directive"
    );
    /**
     * Name of command line parameter - if <code>true</code> skip LiveCycle call
     * during file download.
     */
    public static String BYPASS_LIVE_CYCLE = "bypass_livecycle";

    /*
     * Key for error message that can be returned by download servlet
     */
    public static String WS_DOWNLOAD_ERROR_KEY = "DOWNLOAD_ERROR_MESSAGE";

    /*
     * PDF file type description
     */
    public static String DOWNLOAD_FILE_PDF_TYPE = "PDF";

    /*
     * TIF file type description
     */
    public static String DOWNLOAD_FILE_TIF_TYPE = "TIFF";

    /*
     * PDF file default extension
     */
    public static String DOWNLOAD_FILE_PDF_EXT = ".pdf";

    /*
     * TIF file default extension
     */
    public static String DOWNLOAD_FILE_TIF_EXT = ".tif";

}
