/*
 * @(#)SearchAppBase.java  1.0
 *
 * Copyright (c) 2006 The Boeing Company All rights reserved.
 */

package com.boeing.redars.searchclient;

import com.boeing.redars.SSLInitializer.SSLInitializer;
import com.boeing.redars.cookieanalyser.analyser.CookieAnalyser;
import com.boeing.redars.cookieanalyser.analyser.CookieAnalyserImpl;
import com.boeing.redars.cookieanalyser.analyser.CookieSourceImpl;
import com.boeing.redars.cookieanalyser.except.CookieAnalysisException;
import com.boeing.redars.searchclient.mappings.*;
import com.boeing.redars.searchclient.namemanagement.UniqueNamesHolder;
import com.boeing.redars.searchclient.proxy.soap.RedarsSearchWebServiceAdaptorBindingStub;
import com.boeing.redars.searchclient.proxy.soap.RedarsSearchWebServiceAdaptorService;
import com.boeing.redars.searchclient.proxy.soap.RedarsSearchWebServiceAdaptorServiceLocator;
import com.boeing.redars.unitidparser.config.DocumentUnitIdConstants;
import com.boeing.redars.unitidparser.contract.AttributeInfo;
import com.boeing.redars.utils.StringHelper;
import org.apache.axis.AxisFault;
import org.apache.axis.configuration.FileProvider;
import org.apache.axis.encoding.Base64;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Options;
import org.apache.log4j.Logger;

import javax.xml.soap.MimeHeader;
import javax.xml.soap.MimeHeaders;
import java.io.*;
import java.net.URL;
import java.util.*;

/**
 * This class represents base class for two Search WS Clients
 *
 * @author Pavel Kozlov
 * @version 1.0
 */
public class SearchAppBase {

    private static String TRUST_STORE_FILE_NAME_KEY = "trust.store.file";
    private static String TRUST_STORE_PASSWORD_FILE_NAME_KEY =
        "trust.store.auth.file";
    private static String KEY_STORE_FILE_NAME_KEY = "key.store.file";
    private static String KEY_STORE_PASSWORD_FILE_NAME_KEY =
        "key.store.auth.file";
    private static String KEY_STORE_TYPE_KEY =
        "key.store.type";
    private static String LINE_SEPARATOR =
        System.getProperty("line.separator");

    private static boolean s_rewriteMetaFile;

    private static String s_metaFileName = null;

    private static UniqueNamesHolder s_nameHldr = new UniqueNamesHolder();
    /**
     * Version of Search WS Clients
     */
    protected static String version = "N/A";
    /** Request parameter name - bypass LiveCycle */
    private final static String BYPASS_LIVE_CYCLE_PARAM = "&bypass_livecycle";

    static {

        s_rewriteMetaFile = true;

        try {
            Properties systemProperties = new Properties();
            systemProperties.load(
                ClassLoader.getSystemResourceAsStream("system.properties")
            );
            Enumeration en = systemProperties.keys();
            while (en.hasMoreElements()) {
                String key = (String) en.nextElement();
                if ("version".equalsIgnoreCase(key)) {
                    version = systemProperties.getProperty(key);
                    break;
                }
            }
        } catch (Exception e) {

        }
    }

    protected static CookieAnalyser m_cookieAnalyser = new CookieAnalyserImpl();

    protected static Logger m_logger = Logger.getLogger(SearchAppBase.class);

    private static final String AXIS_CONFIG_FILE_NAME = "axis-config.wsdd";

    /**
     * This method creates comment string, that represent input line
     * and process status for it
     *
     * @param inItem
     * @param delimiter
     * @return comment string
     */
    protected static String createComment(
        CLParameters pars,
        SearchCollectionObject inItem,
        String delimiter
    ) {

        StringBuffer comment = new StringBuffer();
        String inLine = inItem.getInLine();
        if (inLine.startsWith("#") || "".equals(inLine)) {
            comment.append(inLine);
        } else {
            comment.append("<");
            comment.append(inLine);
            comment.append(">");
            String msg = inItem.getParseWarning();
            if (msg != null && !"".equals(msg)) {
                comment.append(delimiter);
                comment.append("[Warning: ");
                comment.append(msg);
                comment.append("]");
            }
            comment.append(delimiter);
            comment.append("status=");
            if (inItem.getStatus() == ResponseStatusKeys.SEARCH_CODE_IGNORED) {
                comment.append("ignored");
            } else if (inItem.getStatus() == ResponseStatusKeys.SEARCH_CODE_OK){
                comment.append("OK");
            } else {
                comment.append("" + inItem.getStatus());
            }
            if (inItem.getStatus() != 0) {
                msg = inItem.getErrMessage();
                if (msg != null && !"".equals(msg)) {
                    comment.append(delimiter);
                    comment.append("errorString=");
                    comment.append(msg);
                }
            }
            printLogMsg(
                pars.isNoLog(),
                pars.getLogFile(),
                comment.toString() + "\n"
            );
            comment.insert(0, "# Line ");
        }
        return comment.toString();
    }

    /**
     * This method adds formatted output lines, that represent result of search,
     * into result lines and calls components download if it is needed
     *
     * @param pars
     * @param delimiter
     * @param results
     * @param sItem
     */
    protected static void processResponse(
        CLParameters pars,
        String delimiter,
        List results,
        ItemSearchStatusXML sItem,
        URL url,
        Map attrsInfo
    ) {

        if (sItem == null) {
            printLogMsg(
                pars.isNoLog(),
                pars.getLogFile(),
                "SearchItemStatusXML object is null. "
                + "Search Result processing has been broken."
                + LINE_SEPARATOR
            );
            return;
        }

        UnitSearchResultXML[] searchResults = sItem.getSearchResults();
        String logMsg;

        if (searchResults != null && searchResults.length > 0) {
            logMsg = "Found " + searchResults.length + " item(s) for this query";
            results.add("#    " + logMsg);

            Hashtable cookies = null;
            for (int i = 0; i < searchResults.length; i++) {

                // if Cookies are updated after each download request,
                // then new 'Cookie' header is added into next request
                // HTTP headers collection
                try {
                    cookies = m_cookieAnalyser.getCookieHeaders(url);
                } catch (Exception e) {
                    cookies = new Hashtable();
                }

                UnitSearchResultXML resp = null;
                String unitDir = "";
                
                try {
                    resp = searchResults[i];
                    results.add(
                        SearchTextOutputFormater.makeUnitStringBuffer(
                            resp, delimiter, attrsInfo
                        )
                    );

                    unitDir = SearchTextOutputFormater.getUnitIdAsString(
                        resp, attrsInfo
                    );
                } catch (Exception e) {
                    printLogMsg(
                        pars.isNoLog(),
                        pars.getLogFile(),
                        "An error occured while Search Result processing."
                        + LINE_SEPARATOR
                        + "Error message is: " + e.getMessage()
                        + LINE_SEPARATOR
                    );
                    continue;
                }

                ComponentFileXML[] fileArray = resp.getFileArray();
                if (fileArray != null && fileArray.length > 0) {

                    results.add("# DU components were returned:");

                    if (pars.isDownload()) {
                        printLogMsg(
                            pars.isNoLog(),
                            pars.getLogFile(),
                            "Downloading components" + LINE_SEPARATOR
                        );
                     }

                    for (int j = 0; j < fileArray.length; j++) {
                        try {
                            results.add(
                                SearchTextOutputFormater.makeFileStringBuffer(
                                    resp,
                                    fileArray[j],
                                    delimiter,
                                    attrsInfo
                                )
                            );
                        } catch (Exception e) {
                            printLogMsg(
                                pars.isNoLog(),
                                pars.getLogFile(),
                                "An error occured while found DU component "
                                + "metadata processing."
                                + LINE_SEPARATOR
                                + "Error message is: " + e.getMessage()
                                + LINE_SEPARATOR
                            );
                            continue;
                        }
                        if (pars.isDownload()) {
                            try {
                                downloadComponent(
                                    resp.getUnitSystemId(),
                                    fileArray[j],
                                    pars,
                                    unitDir,
                                    cookies
                                );
                            } catch (Exception e) {
                                printLogMsg(
                                    pars.isNoLog(),
                                    pars.getLogFile(),
                                    "An error occured while downloading :"
                                    + LINE_SEPARATOR
                                    + "Error message is: " + e.getMessage()
                                    + LINE_SEPARATOR
                                );
                                if (!pars.isNoLog()) {
                                    try {
                                        e.printStackTrace(
                                            new PrintStream(
                                                new FileOutputStream(
                                                    pars.getLogFile(),
                                                    true
                                                ),
                                                true
                                            )
                                        );
                                    } catch (FileNotFoundException fe) {
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            logMsg = "List of Search Results is empty";
            results.add("#    " + logMsg);
        }

        printLogMsg(
            pars.isNoLog(),
            pars.getLogFile(),
            logMsg + LINE_SEPARATOR + LINE_SEPARATOR
        );

        if (sItem.isHasMore()) {
            results.add("# (has more)");
        }
    }

    /**
     * This method prints usage of client applications
     *
     * @param className - name of class, that represents client application
     * @param options - command line options
     */
    protected static void printUsage(String className, Options options) {

        HelpFormatter formatter = new HelpFormatter();
        formatter.printHelp (
            128,
            " "
            + className
            + " "
            + "[-url <target_url>] "
            + "[-host <target_host>] "
            + "[-port <target_port>] "
            + "[-user <effective_user_id>] "
            + "[-trusted_app_id <trusted_application_id>] "
            + "[-chunk_size <chunk_size>] "
            + "[-i <input_file_path>]"
            + "[-o <output_file_name>] "
            + "[-l <log_file_name>] "
            + "[-nolog] "
            + "[-pipe] "
            + "[-download] "
            + "[-download_dir <dir>] "
            + "[-meta_info_file <meta_info_file_name>] "
            + "[-meta_info <ALL>|<RENAMED>]",
            "parameters:",
            options,
            "\nApplication uses following files, what must be in the classpath:\n"
            + "activation.jar\n"
            + "axis.jar\n"
            + "commons-cli-1.0.jar\n"
            + "commons-discovery-0.2.jar\n"
            + "commons-logging-1.0.4.jar\n"
            + "jaxrpc.jar\n"
            + "log4j-1.2.8.jar\n"
            + "mail.jar\n"
            + "saaj.jar\n"
            + "test_search.jar\n"
            + "utils.jar\n"
            + "wsdl4j-1.5.1.jar",
            false
        );

    }

    /**
     * This method prints affected set of application parameters
     * @param logFile - name of log file
     * @param pars - parameters
     */
    protected static void printParameters(String logFile, CLParameters pars) {

        if (
            !"".equals(logFile) && logFile != null && pars != null
        ) {
            try {
                BufferedWriter bw =
                    new BufferedWriter(new FileWriter(logFile, true));
                bw.write("Using parameters:\n");
                if (
                    pars.getUrl() != null
                    && !"".equals(pars.getUrl())
                ) {
                    bw.write(" -url " + pars.getUrl() + "\n");
                } else {
                    bw.write(
                        " -host "
                        + pars.getHost()
                        + "\n -port "
                        + pars.getPort()
                        + "\n"
                    );
                }
                bw.write(" -user " + pars.getUserId() + "\n");
                bw.write(" -trusted_app_id " + pars.getTrustedAppId() + "\n");
                bw.write(" -chunk_size " + pars.getChunkSize() + "\n");
                if (
                    !"".equals(pars.getInputFile())
                    && pars.getInputFile() != null
                ) {
                    bw.write(" -i " + pars.getInputFile() + "\n");
                }
                if (
                    !"".equals(pars.getOutputFile())
                    && pars.getOutputFile() != null
                ) {
                    bw.write(" -o " + pars.getOutputFile() + "\n");
                }
                bw.write(" -l " + pars.getLogFile() + "\n");
                if (pars.isNoLog()) {
                    bw.write(" -nolog\n");
                }
                if (pars.isPipeLine()) {
                    bw.write(" -pipe\n");
                }
                if (pars.isDownload()) {
                    bw.write(" -download\n");
                    if (
                        !"".equals(pars.getDownloadDir())
                        && pars.getDownloadDir() != null
                    ) {
                        bw.write(" -download_dir " + pars.getDownloadDir() + "\n");
                    }
                }

                bw.write("\n");
                bw.flush();
            } catch (IOException ioe) {
            }
        }
    }

    /**
     * This method prints message into log file
     *
     * @param noLogFlag
     * @param logFile
     * @param msg
     */
    protected static void printLogMsg (
        boolean noLogFlag,
        String logFile,
        String msg
    ) {

        if (
            !noLogFlag
            && !SSLInitializer.isEmpty(logFile)
            && !SSLInitializer.isEmpty(msg)
        ) {
            try {
                BufferedWriter bw =
                    new BufferedWriter(new FileWriter(logFile, true));
                bw.write(msg);
                bw.flush();
            } catch (IOException ioe) {
            }
        }
    }

    /**
     * This method prints strings to file
     *
     * @param outputFile
     * @param result
     * @param isAddToFile
     */
    protected static void printResults (
        String outputFile, String[] result, boolean isAddToFile
    ) {

        if (result != null) {
            try {

                BufferedWriter bw = null;
                if (outputFile != null) {
                    bw = new BufferedWriter(
                        new FileWriter(outputFile, isAddToFile)
                    );
                } else {
                    bw = new BufferedWriter(
                        new OutputStreamWriter(System.out)
                    );
                }
                for (int i = 0; i < result.length; i++) {
                    bw.write(result[i] + "\n");
                }
                bw.flush();
            } catch (IOException ioe) {
            }
        }
    }

    /**
     * This method determines final name of directory, which will be used to
     * store downloaded content.
     *
     * @param initDir file name to be used for creating of valid
     * final directory name.
     *
     * @return string represented directory name.
     */
    protected static String findValidDirectoryName(final String initDir) {
        return s_nameHldr.generateUniqueName(initDir);
    }

    /**
     * This method determines final file name that will be used to
     * store downloaded content.
     *
     * @param dirName directory that will contain downloaded content
     * @param initFileName file name to be used for creating of valid
     * final file name.
     *
     * @return string represented file name.
     */
    protected static String findValidFileName(
        final String dirName, final String initFileName
    ) {
        UniqueNamesHolder holder = s_nameHldr.getChildHolderByUniqueName(
            dirName
        );
        return holder.generateUniqueName(initFileName);
    }

    /**
     * This method prints downloaded files info into appropriate log-file
     *
     * @param metaInfoFileName name of log-file
     * @param originName original name of file (can contain restricted chars)
     * @param realDirName name of directory that contains downloaded content
     * @param realFileName name of file that stores downloaded content
     */
    protected static void printMetaInfo(
        final String metaInfoFileName,
        final String originName,
        final String realDirName,
        final String realFileName
    ) {

        if (StringHelper.isEmptyString(metaInfoFileName)) {
            return;
        }

        StringBuffer sb = new StringBuffer(originName);
        sb.append("\t");
        sb.append(realDirName);
        if (sb.charAt(sb.length() - 1) != File.separatorChar) {
            sb.append(File.separator);
        }
        sb.append(realFileName);
        sb.append(LINE_SEPARATOR);

        try {

            BufferedWriter bw = new BufferedWriter(
                new FileWriter(metaInfoFileName, true)
            );
            bw.write(sb.toString());
            bw.flush();
            bw.close();
        } catch (IOException ioe) {

        }
    }

    /**
     * This method initialize meta-info printing process
     *
     * @param pars application configuration
     *
     * @return name of file to be used for printing of meta-info
     * @throws IOException can be thrown while file preparation
     */
    protected static String prepareMetaFile(final CLParameters pars)
    throws IOException {

        if (
            StringHelper.isEmptyString(s_metaFileName)
            && !StringHelper.isEmptyString(pars.getDownloadDir())
        ) {

            File file = new File(pars.getDownloadDir());
            file.mkdirs();

            StringBuffer sb = new StringBuffer(pars.getDownloadDir());
            if (sb.charAt(sb.length() - 1) != File.separatorChar) {
                sb.append(File.separator);
            }
            sb.append(pars.getMetaInfoFileName());

            s_metaFileName = sb.toString();

            file = new File(s_metaFileName);
            if (!file.exists()) {
                file.createNewFile();
            } else if (s_rewriteMetaFile) {
                FileWriter writer = new FileWriter(file, false);
                writer.write("");
                writer.flush();
                writer.close();
            }
            s_rewriteMetaFile = false;
        }
        return s_metaFileName;
    }

    /**
     * This method downloads DU components using class DocDownloader
     *
     * @param unitSystemId Component unit system Id
     * @param cf           Component attribute
     * @param pars         WS client parameters
     * @param unitDir      Output unit directory name
     * @param cookies      HTTP cookies
     * @throws IOException can be thrown while downloading
     */
    private static void downloadComponent(
        long unitSystemId,
        final ComponentFileXML cf,
        final CLParameters pars,
        final String unitDir,
        final Hashtable cookies
    ) throws IOException {

        final StringBuilder params = new StringBuilder(
            "/redars/webservices/RedarsRetrieveContentWeb?documentUnitId="
        );
        params.append(unitSystemId);
        params.append("&sequence=").append(cf.getSequence());
        params.append("&EffectiveUserId=").append(pars.getUserId());
        if (pars.isBypassLiveCycle()) {
            params.append(BYPASS_LIVE_CYCLE_PARAM);
        }
        URL aURL = new URL(
            pars.getProtocol(),
            pars.getHost(),
            pars.getPort(),
            params.toString()
        );

        // directory name preparation
        final String validUnitDirName = findValidDirectoryName(unitDir);

        // file extension determination
        final String fileExt = (
            cf.getType().equalsIgnoreCase(
                SearchDownloadConstants.DOWNLOAD_FILE_TIF_TYPE
            )
            ? SearchDownloadConstants.DOWNLOAD_FILE_TIF_EXT
            : SearchDownloadConstants.DOWNLOAD_FILE_PDF_EXT
        );

        // file name generation
        String exportFilename = (
            unitDir
            + SearchTextOutputFormater.getComponentAttrsAsString(cf)
        );
        String validFileName = findValidFileName(
            validUnitDirName, exportFilename
        );

        // finalize file name
        validFileName = validFileName + fileExt;

        String basicAuth = (
            "Basic "
            + Base64.encode(
                (pars.getTrustedAppId() + ":" + pars.getPassword()).getBytes()
            )
        );
        PrintStream out;
        if (pars.isNoLog()) {
            out = System.out;
        } else {
            try {
                out = new PrintStream(
                    new FileOutputStream(pars.getLogFile(), true),
                    true
                );
            } catch (FileNotFoundException e) {
                out = System.out;
            }
        }

        final String metaFileName = prepareMetaFile(pars);
        final boolean success = DocDownloader.downloadUnitComponent(
            aURL.toString(),
            validFileName,
            pars.getDownloadDir(),
            validUnitDirName,
            basicAuth,
            out,
            cookies
        );

        final boolean printInfo = (
            CLParameters.COLLECT_ALL_FILE_MAPPING.equalsIgnoreCase(
                pars.getMetaInfoDirective()
            ) || (
                CLParameters.COLLECT_RENAMED_FILE_MAPPING.equalsIgnoreCase(
                    pars.getMetaInfoDirective()
                ) && !validUnitDirName.equals(unitDir)
            )
        );

        if (success && printInfo) {
            printMetaInfo(
                metaFileName,
                exportFilename,
                validUnitDirName,
                validFileName
            );
        }
    }

    /**
     * This method retrieves http header fields for given http header
     *
     * @param proxy
     * @param headerName
     * @return array of string-represented fields for given http header
     */
    protected static String[] retrieveSetCookieFields(
        RedarsSearchWebServiceAdaptorBindingStub proxy,
        String headerName
    ) {

        List resultList = new ArrayList();
        m_logger.debug(
            "SearchAppBase.retrieveSetCookieFields() - start execution."
        );
        try {
            MimeHeaders headers =
                proxy._getCall().getMessageContext().getResponseMessage().getMimeHeaders();

            m_logger.debug(
                "Response contains next '" + headerName + "' fields:"
            );
            Iterator itr = headers.getAllHeaders();
            while (itr.hasNext()) {
                MimeHeader header = (MimeHeader) itr.next();
                if (header.getName().equalsIgnoreCase(headerName)) {
                    m_logger.debug(header.getValue());
                    resultList.add(header.getValue());
                }
            }
        } catch (Exception e) {
            m_logger.fatal(
                "Error was occured while retrieving '" + headerName + "' fields",
                e
            );
        } finally {
            m_logger.debug(
                "SearchAppBase.retrieveSetCookieFields() - end execution."
            );
        }

        return (String[]) resultList.toArray(new String[resultList.size()]);
    }

    /**
     * This method collects client cookies. All errors messages is written
     * using apache log4j Logger.
     *
     * @param headerName
     * @param headerFields
     * @param url
     */
    public static void updateCookies(
        String headerName,
        String[] headerFields,
        URL url
    ) {
        m_logger.debug(
            "SearchAppBase.updateCookies() - start execution."
        );
        try {
            if (headerFields == null || headerFields.length == 0) {
                m_logger.debug(
                    "There are no any new '"
                    + headerName
                    + "' fields!"
                );
                return;
            }
            CookieSourceImpl source = new CookieSourceImpl();
            source.setUrl(url);
            for (int i = 0; i < headerFields.length; i++) {
                try {
                    source.addHeaderField(
                        headerName,
                        headerFields[i]
                    );
                } catch (CookieAnalysisException e) {
                    m_logger.error(
                        "Error was occured while adding '"
                        + headerName
                        + "' field to 'CookieSource' object.",
                        e
                    );
                }
            }

            m_cookieAnalyser.updateCookies(source);

        } catch (Exception e) {
            m_logger.error(
                "Error was occured while updating Cookie collection.'",
                e
            );
        } finally {
            m_logger.debug(
                "SearchAppBase.updateCookies() - end execution."
            );
        }
    }

    /**
     * This method prepares RedarsSearchWebServiceAdaptorBindingStub object
     * that is responsible for WS methods invocation
     *
     * @param url
     * @param trustedAppId
     * @param password
     * @return RedarsSearchWebServiceAdaptorBindingStub
     * @throws AxisFault
     */
    protected static RedarsSearchWebServiceAdaptorBindingStub prepareProxy (
        URL url,
        String trustedAppId,
        String password
    ) throws AxisFault {

        RedarsSearchWebServiceAdaptorService service = null;
        try {
            FileProvider config = new FileProvider(AXIS_CONFIG_FILE_NAME);
            service = new RedarsSearchWebServiceAdaptorServiceLocator(config);
        } catch (Exception e) {
            m_logger.debug(
                "Error was occured while custom "
                + "RedarsSearchWebServiceAdaptorService object creation!"
                + "Default Axis object is used."
            );
        }

        RedarsSearchWebServiceAdaptorBindingStub proxy =
            new RedarsSearchWebServiceAdaptorBindingStub(url, service);
        proxy.setUsername(trustedAppId);
        proxy.setPassword(password);

        return proxy;
    }

    /**
     * This method sets up SSL System properties
     */
    protected static void initializeSSL(CLParameters pars) {
        String warn = SSLInitializer.initialize(
            System.getProperty(TRUST_STORE_FILE_NAME_KEY),
            System.getProperty(TRUST_STORE_PASSWORD_FILE_NAME_KEY),
            System.getProperty(KEY_STORE_FILE_NAME_KEY),
            System.getProperty(KEY_STORE_PASSWORD_FILE_NAME_KEY),
            System.getProperty(KEY_STORE_TYPE_KEY)
        );
        if (!SSLInitializer.isEmpty(warn)) {
            printLogMsg(
                pars.isNoLog(),
                pars.getLogFile(),
                LINE_SEPARATOR
                + "[Warning]"
                + LINE_SEPARATOR
                + warn
                + LINE_SEPARATOR
            );
        }
    }

    /**
     * This method creates collection of DUUID attributes info
     *
     * @return collection of DUUID attributes info
     */
    static Map createAttributesInfo() {

        Map result = new HashMap();
        AttributeInfo info = new AttributeInfo(
            DocumentUnitIdConstants.DOC_UNIT_BASE_NUMBER_ATTR,
            "getBaseDocumentNumber"
        );
        result.put(
            DocumentUnitIdConstants.DOC_UNIT_BASE_NUMBER_ATTR,
            info
        );

        info = new AttributeInfo(
            DocumentUnitIdConstants.DOC_UNIT_CAGE_CODE_ATTR,
            "getCageCode"
        );
        result.put(
            DocumentUnitIdConstants.DOC_UNIT_CAGE_CODE_ATTR,
            info
        );

        info = new AttributeInfo(
            DocumentUnitIdConstants.DOC_UNIT_MODEL_ATTR,
            "getModel"
        );
        result.put(
            DocumentUnitIdConstants.DOC_UNIT_MODEL_ATTR,
            info
        );

        info = new AttributeInfo(
            DocumentUnitIdConstants.DOC_UNIT_DASH_NUMBER_ATTR,
            "getDashNumber"
        );
        result.put(
            DocumentUnitIdConstants.DOC_UNIT_DASH_NUMBER_ATTR,
            info
        );

        info = new AttributeInfo(
            DocumentUnitIdConstants.DOC_UNIT_TYPE_ATTR,
            "getUnitType"
        );
        result.put(
            DocumentUnitIdConstants.DOC_UNIT_TYPE_ATTR,
            info
        );

        info = new AttributeInfo(
            DocumentUnitIdConstants.DOC_UNIT_OWNER_COMPANY_CODE_ATTR,
            "getOwnerCompanyCode"
        );
        result.put(
            DocumentUnitIdConstants.DOC_UNIT_OWNER_COMPANY_CODE_ATTR,
            info
        );

        info = new AttributeInfo(
            DocumentUnitIdConstants.DOC_UNIT_SUB_ID_ATTR,
            "getId"
        );
        result.put(
            DocumentUnitIdConstants.DOC_UNIT_SUB_ID_ATTR,
            info
        );

        info = new AttributeInfo(
            DocumentUnitIdConstants.DOC_UNIT_REVISION_ATTR,
            "getRevision"
        );
        result.put(
            DocumentUnitIdConstants.DOC_UNIT_REVISION_ATTR,
            info
        );

        info = new AttributeInfo(
            DocumentUnitIdConstants.DOC_UNIT_REISSUE_ATTR,
            "getReissue"
        );
        result.put(
            DocumentUnitIdConstants.DOC_UNIT_REISSUE_ATTR,
            info
        );

        info = new AttributeInfo(
            DocumentUnitIdConstants.DOC_UNIT_VOLUME_PART_ATTR,
            "getVolumePartPage"
        );
        result.put(
            DocumentUnitIdConstants.DOC_UNIT_VOLUME_PART_ATTR,
            info
        );

        return result;
    }
}
