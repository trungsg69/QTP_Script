/*
 * @(#)AutomatedInternalSearchDocuments.java
 *
 * Copyright (c) 2006 The Boeing Company. All Rights Reserved.
 */

package com.boeing.redars.searchclient;

import com.boeing.redars.searchclient.proxy.soap.*;
import com.boeing.redars.searchclient.mappings.*;
import com.boeing.redars.inputpaging.PagingHelper;

import org.apache.axis.transport.http.HTTPConstants;

import java.text.ParseException;
import java.net.URL;
import java.util.*;
import java.io.*;

/**
 * This class represents search for documents using system document unit ID
 * as search criteria
 *
 * @author Pavel Kozlov
 * @version 1.0
 */
public class AutomatedInternalSearchDocuments  extends SearchAppBase {

    /**
     * This is a main method of class.
     * It represent search function invoking WS method
     * using internal search items
     *
     * @param args
     */
    public static void main(String[] args) {

        Date curDate = new Date();
        CLParser cmdLnParser = new CLParser("search", curDate);
        CLParameters clParams = new CLParameters();
        // set prefix for log file name. If command line
        // provide log file name then this prefix will be ignored and if not
        //then log file name will be like this mask "prefix_MM_dd_yyyy_HH_mm.log"
        clParams.setLogFilePrefix("search");
        PagingHelper items = new PagingHelper();

        //prepare input reader
        BufferedReader ibr = new BufferedReader(
            new InputStreamReader(System.in)
        );

        String delimiter = "\t";
        try {
            cmdLnParser.parse(args, clParams);

            if (clParams.isPipeLine()) {
                delimiter = "|";
            }
            
            items.setDefPageSize(clParams.getChunkSize());

            if (!clParams.isNoLog()) {
                printLogMsg(
                    clParams.isNoLog(),
                    clParams.getLogFile(),
                    "\n["
                    + curDate.toString()
                    + "]\n"
                    + "AutomatedSearchDocuments\n"
                    + "Version " + version + "\n"
                    + "=============================================\n\n"
                );
                printParameters(
                    clParams.getLogFile(),
                    clParams
                );
            }
            initializeSSL(clParams);
            boolean useStdIn = true;
            if (
                !"".equals(clParams.getInputFile())
                && clParams.getInputFile() != null
            ) {
                try {
                    ibr = new BufferedReader(
                        new FileReader(clParams.getInputFile())
                    );
                    printLogMsg(
                        clParams.isNoLog(),
                        clParams.getLogFile(),
                        "Opening file "
                            + clParams.getInputFile()
                            + "\n\n"
                    );

                    useStdIn = false;
                } catch (FileNotFoundException ioe) {
                    String msg =
                        "Can't find file " + clParams.getInputFile() + "\n";
                    printLogMsg(
                        clParams.isNoLog(),
                        clParams.getLogFile(),
                        msg
                    );
                    System.out.print(msg);
                }
            }
            if (useStdIn) {
                System.out.println(
                    "Waiting for input data (click twice ENTER button "
                    + "to confirm input):"
                );
            }

            //get input data
            //try to create InternalDocumentUnitItem for each input line.

            SearchItemPopulator sip = new SearchItemPopulator();
            sip.setArgSeparator(delimiter);

            SearchCollectionObject item;
            int lineCnt = 1;

            while (true) {
                String line = ibr.readLine();
                //check for end of data
                if (
                    line == null
                    || (useStdIn && "".equals(line))
                ) {
                    break;
                }
                //try to create InternalDocumentUnitItem
                item = new SearchCollectionObject(line, null);
                if (!"".equals(line) && !line.startsWith("#")) {
                    try {
                        item = sip.createIntItem(line);
                        if (
                            item.getParseWarning() != null
                            && !"".equals(item.getParseWarning())
                        ) {
                            printLogMsg(
                                clParams.isNoLog(),
                                clParams.getLogFile(),
                                "[Warning] Line "
                                + lineCnt
                                + ": "
                                + item.getParseWarning()
                                + "\n"
                            );
                        }
                    } catch (InputParseException pe) {
                        item.setErrMessage(pe.getMessage());
                        item.setStatus(ResponseStatusKeys.SEARCH_CODE_IGNORED);
                        printLogMsg(
                            clParams.isNoLog(),
                            clParams.getLogFile(),
                            "[ERROR] Line "
                            + lineCnt
                            + ": "
                            + pe.getMessage()
                            + "\n"
                        );

                    }
                }
                items.addObject(item);
                lineCnt++;
            }

            if (items.size() == 0) {
                printLogMsg(
                    clParams.isNoLog(),
                    clParams.getLogFile(),
                    "No input data"
                );

                if (useStdIn) {
                    System.out.println("Input data was not assigned!");
                }
                System.exit(0);
            } else if (useStdIn) {
                System.out.println("Input data was assigned");
            }

            //prepare InternalRequest
            InternalDocumentRequestXML intRequest = (
                new InternalDocumentRequestXML()
            );
            //intRequest.setTrustedApplicationId(clParams.getTrustedAppId());
            intRequest.setUserId(clParams.getUserId());
            //prepare target url and proxy
            URL url;
            if (
                "".equals(clParams.getUrl())
                || clParams.getUrl() == null
            ) {
                url = new URL("https",
                    clParams.getHost(),
                    clParams.getPort(),
                    "/redars/webservices/amrpcrouter"
                );
            } else {
                url = new URL(clParams.getUrl());
            }
            //prepare proxy
            RedarsSearchWebServiceAdaptorBindingStub proxy = prepareProxy(
                url,
                clParams.getTrustedAppId(),
                clParams.getPassword()
            );

            //prepare chunk and invoke search method
            boolean addLines = false;
            Map attrsInfo = createAttributesInfo();
            
            while (items.hasNext()) {
                //For each chunk prepare request items
                PagingHelper.PageIterator itr = items.next();
                int validObjInd = 0;
                InternalDocUnitItemXML[] intItems =
                    new InternalDocUnitItemXML[itr.getValidObjCnt()];
                while (itr.hasNext()) {
                    item = (SearchCollectionObject) itr.next();
                    if (item.getRequestItem() != null) {
                        intItems[validObjInd++] =
                            (InternalDocUnitItemXML) item.getRequestItem();
                    }
                }
                printLogMsg(
                    clParams.isNoLog(),
                    clParams.getLogFile(),
                    "" + intItems.length
                    + " item(s) was(were) created from "
                    + itr.getPageSize()
                    + " input line(s)\n"
                );

                DocumentSearchResponseXML response = null;
                ItemSearchStatusXML[] sItems = null;
                //if request items present, then invoke WS method
                if (intItems.length > 0) {
                    intRequest.setDocUnitItems(intItems);
                    printLogMsg(
                        clParams.isNoLog(),
                        clParams.getLogFile(),
                        "Making an InternalDocumentRequest to "
                        + url.toString()
                        + "\n"
                    );
                    //invoke Search method
                    proxy.setCookieHeaders(
                        m_cookieAnalyser.getCookieHeaders(url)
                    );
                    response = proxy.searchForDocUnitsInternal(intRequest);

                    //process Set-Cookie HTTP header
                    String[] cookieFields = (
                        retrieveSetCookieFields(
                            proxy,
                            HTTPConstants.HEADER_SET_COOKIE
                        )
                    );
                    updateCookies(
                        HTTPConstants.HEADER_SET_COOKIE,
                        cookieFields,
                        url
                    );

                    //process response
                    printLogMsg(
                        clParams.isNoLog(),
                        clParams.getLogFile(),
                        "DocumentSearchResponseXML.getStatus()."
                        + "getCode(): "
                        + response.getStatus().getCode()
                        + "\nDocumentSearchResponseXML."
                        + "getStatus().getMessage(): "
                        + response.getStatus().getMessage()
                        + "\n"
                    );
                    sItems = response.getSearchItemStatuses();
                    if (sItems == null || sItems.length == 0 ) {
                        printLogMsg(
                            clParams.isNoLog(),
                            clParams.getLogFile(),
                            "No items were returned\n"
                        );

                    } else {
                        printLogMsg(
                            clParams.isNoLog(),
                            clParams.getLogFile(),
                            "" + sItems.length + " item(s) was(were) returned\n"
                        );
                    }
                }

                //for each chunk prepare result strings
                List resultLinesList = new ArrayList();
                itr.first();
                int valItemsCnt = 0;

                while (itr.hasNext()) {
                    item = (SearchCollectionObject) itr.next();
                    ItemSearchStatusXML sItem = null;
                    //creating comments for input line
                    if (item.getRequestItem() != null) {
                        if (sItems != null && valItemsCnt < sItems.length) {
                            sItem = sItems[valItemsCnt++];
                            item.setStatus(
                                sItem.getSearchStatus().getCode()
                            );
                            item.setErrMessage(
                                sItem.getSearchStatus().getMessage()
                            );
                        } else {
                            item.setStatus(response.getStatus().getCode());
                            item.setErrMessage(
                                response.getStatus().getMessage()
                            );
                        }
                    }

                    resultLinesList.add(
                        createComment(
                            clParams,
                            item,
                            delimiter
                        )
                    );

                    //creating output strings for result of query
                    if (item.getRequestItem() != null && sItem != null) {
                        //create output strings for current input line
                        processResponse(
                            clParams,
                            delimiter,
                            resultLinesList,
                            sItem,
                            url,
                            attrsInfo
                        );
                    }
                }

                //printing output strings
                String[] resStrings = new String[resultLinesList.size()];
                resStrings = (String[]) resultLinesList.toArray(
                    resStrings
                );
                printResults(clParams.getOutputFile(), resStrings, addLines);
                addLines = true;
            }

        } catch (ParseException pe) {
            String msg =
                "Error occured in parameter parsing:\n" + pe.getMessage();
            System.err.println("\n" + msg + "\n");
            printUsage(
                AutomatedExternalSearchDocuments.class.getName(),
                cmdLnParser.getOptions()
            );
            printLogMsg(clParams.isNoLog(), clParams.getLogFile(), msg);
            System.exit(1);
        } catch (java.util.MissingResourceException mre) {
            System.err.println(
                "Can't find configuration file 'search.properties'"
            );
            System.exit(1);
        } catch (Exception e) {
            System.err.println("Caught exception: " + e.getMessage());
            e.printStackTrace();
            printLogMsg(
                clParams.isNoLog(),
                clParams.getLogFile(),
                "Caught exception: " + e.getMessage() + "\n"
            );
        }
        finally {
            try {
                ibr.close();
            } catch (IOException e) {
                System.err.println(
                    "BufferedReader cannot be closed. " + e.getMessage()
                );
            }
        }
    }
}
