/**
 * RedarsSearchWebServiceAdaptorService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package com.boeing.redars.searchclient.proxy.soap;

public interface RedarsSearchWebServiceAdaptorService extends javax.xml.rpc.Service {
    public java.lang.String getRedarsSearchWebServiceAdaptorPortAddress();

    public com.boeing.redars.searchclient.proxy.soap.RedarsSearchWebServiceAdaptor getRedarsSearchWebServiceAdaptorPort() throws javax.xml.rpc.ServiceException;

    public com.boeing.redars.searchclient.proxy.soap.RedarsSearchWebServiceAdaptor getRedarsSearchWebServiceAdaptorPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
