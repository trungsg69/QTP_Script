/*
 * @(#)CLParser.java
 *
 * Copyright (c) 2006 The Boeing Company. All Rights Reserved.
 */

package com.boeing.redars.searchclient;

import com.boeing.redars.commandlineparser.common.CommandLineParametersBase;
import com.boeing.redars.utils.StringHelper;
import org.apache.commons.cli.Option;

import java.text.ParseException;
import java.util.Date;

/**
 * This class extends base command line parser for process additional
 * command line parameters (-download, -download_dir)
 *
 * @author Pavel Kozlov
 * @version 1.0
 */
public class CLParser extends com.boeing.redars.commandlineparser.common.CommandLineParserBase {

    /**
     * Constructor for parser.
     * When parser will be created, base and additional command line options
     * will be created automatically.
     *
     * @param cfgFile Configuration file name
     * @param actDate Actual date
     */
    public CLParser(final String cfgFile, final Date actDate) {

        super(cfgFile, actDate);

        // adding of <b>DOWNLOAD</b> option
        Option option = new Option(
            SearchDownloadConstants.DOWNLOAD_FLAG,
            "flag for activate download"
        );
        option.setArgs(0);
        option.setRequired(false);
        option.setOptionalArg(true);
        addCustomOption(option);

        // adding of <b>DOWNLOAD_DIR</b> option
        option = new Option(
            SearchDownloadConstants.DOWNLOAD_DIR,
            "directory for download files"
        );
        option.setArgs(1);
        option.setArgName(SearchDownloadConstants.DOWNLOAD_DIR_DESK);
        option.setRequired(false);
        option.setOptionalArg(true);
        addCustomOption(option);

        // adding of <b>META INFO FILE NAME</b> option
        option = new Option(
            SearchDownloadConstants.META_INFO_FILE_NAME_PARAM,
            "name of file for storing of download files meta-info"
        );
        option.setArgs(1);
        option.setArgName(
            SearchDownloadConstants.META_INFO_FILE_NAME_PARAM_DESC
        );
        option.setRequired(false);
        option.setOptionalArg(true);
        addCustomOption(option);

        // adding of <b>META INFO DIRECTIVE</b> option
        option = new Option(
            SearchDownloadConstants.COLLECT_META_INFO_DIRECTIVE_PARAM,
            "meta-info collection type"
        );
        option.setArgs(1);
        option.setArgName(
            SearchDownloadConstants.COLLECT_META_INFO_DIRECTIVE_PARAM_DESC
        );
        option.setRequired(false);
        option.setOptionalArg(true);
        addCustomOption(option);
        // adding of <b>Bypass LiveCycle</b> option
        option = new Option(
            SearchDownloadConstants.BYPASS_LIVE_CYCLE,
            "if 'true' skip LiveCycle call during file download"
        );
        option.setArgs(0);
        option.setRequired(false);
        option.setOptionalArg(false);
        addCustomOption(option);
    }

    /**
     * This method prepares additional command line parameters
     * @param clPars          Parameters storage
     * @throws ParseException
     */
    protected void prepareParams(CommandLineParametersBase clPars)
    throws ParseException {

        super.prepareParams(clPars);

        //set DOWNLOAD_FLAG parameter
        String flag = getAttrValue(SearchDownloadConstants.DOWNLOAD_FLAG, true);
        if ("true".equalsIgnoreCase(flag)) {
            ((CLParameters) clPars).setDownload(true);
            //if download = true, set download directory
            ((CLParameters) clPars).setDownloadDir(
                getAttrValue(SearchDownloadConstants.DOWNLOAD_DIR, false)
            );
            ((CLParameters) clPars).setMetaInfoFileName(
                getAttrValue(
                    SearchDownloadConstants.META_INFO_FILE_NAME_PARAM, false
                )
            );
            ((CLParameters) clPars).setMetaInfoDirective(
                getAttrValue(
                    SearchDownloadConstants.COLLECT_META_INFO_DIRECTIVE_PARAM,
                    false
                )
            );
        }
        ((CLParameters) clPars).setBypassLiveCycle(
            Boolean.parseBoolean(
                getAttrValue(
                    SearchDownloadConstants.BYPASS_LIVE_CYCLE,
                    true
                )
            )
        );
    }

    /**
     * This method validates additional parameters
     * @param clPars          Parameters storage
     * @throws ParseException
     */
    public void isParamsValid(CommandLineParametersBase clPars)
    throws ParseException {

        String msg = "";
        try {
            super.isParamsValid(clPars);
        } catch (ParseException e) {
            msg = e.getMessage();
        }

        final StringBuilder validationError = new StringBuilder();
        final StringBuilder paramValidationError = new StringBuilder();
        final StringBuilder valueValidationError = new StringBuilder();
        String delim = "";
        CLParameters params = (CLParameters) clPars;

        if (params.isDownload()) {

            // validate download dir parameter
            if (StringHelper.isEmptyString(params.getDownloadDir())) {

                paramValidationError
                .append(delim)
                .append(SearchDownloadConstants.DOWNLOAD_DIR);
                delim = ", ";
            }

            // validate meta-info file name parameter
            if (StringHelper.isEmptyString(params.getMetaInfoFileName())) {

                paramValidationError
                .append(delim)
                .append(SearchDownloadConstants.META_INFO_FILE_NAME_PARAM);
                delim = ", ";
            }

            // validate meta-info directive parameter
            if (StringHelper.isEmptyString(params.getMetaInfoDirective())) {

                paramValidationError
                .append(delim)
                .append(SearchDownloadConstants.COLLECT_META_INFO_DIRECTIVE_PARAM);
            } else if (
                !CLParameters.COLLECT_ALL_FILE_MAPPING.equalsIgnoreCase(
                    params.getMetaInfoDirective()
                ) && !CLParameters.COLLECT_RENAMED_FILE_MAPPING.equalsIgnoreCase(
                    params.getMetaInfoDirective()
                )
            ) {

                valueValidationError
                .append("Parameter ")
                .append(SearchDownloadConstants.COLLECT_META_INFO_DIRECTIVE_PARAM)
                .append(" can have only '")
                .append(CLParameters.COLLECT_ALL_FILE_MAPPING)
                .append("' or '")
                .append(CLParameters.COLLECT_RENAMED_FILE_MAPPING)
                .append("' value.");
            }
        }

        if (!StringHelper.isEmptyString(msg)) {
            validationError.append(msg.substring(1, msg.length() - 19));
            delim = ", ";
        } else {
            delim = "";
        }
        if (paramValidationError.length() > 0) {
            validationError.append(delim).append(paramValidationError);
        }
        if (validationError.length() > 0) {
            validationError.append(" must be specified.");
            delim = " ";
        } else {
            delim = "";
        }
        if (valueValidationError.length() > 0) {
            validationError.append(delim).append(valueValidationError);
        }
        if (validationError.length() > 0) {
            throw new ParseException(validationError.toString(), 0);
        }
    }

}
