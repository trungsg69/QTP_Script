/*
 * @(#)InputParseException.java
 *
 * Copyright (c) 2006 The Boeing Company. All Rights Reserved.
 */

package com.boeing.redars.searchclient;

/**
 * This class represents universal input parse exception
 *
 * @author Pavel Kozlov
 * @version 1.0
 */
public class InputParseException extends Exception{

    public InputParseException(String msg) {
        super(msg);
    }
}
