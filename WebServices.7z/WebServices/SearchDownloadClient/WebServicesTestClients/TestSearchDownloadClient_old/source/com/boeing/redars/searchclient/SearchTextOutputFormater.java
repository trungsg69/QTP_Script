/*
 * @(#)SearchTextOutputFormater.java
 *
 * Copyright (c) 2007 The Boeing Company. All Rights Reserved.
 */

package com.boeing.redars.searchclient;

import com.boeing.redars.searchclient.mappings.*;
import com.boeing.redars.unitidparser.config.DocumentUnitIdConstants;
import com.boeing.redars.unitidparser.parser.DocumentUnitIdFormatter;
import com.boeing.redars.unitidparser.except.DocumentUnitIdFormatException;
import com.boeing.redars.config.DocumentAttributes;

import java.util.Map;

/**
 * This class provide methods for formatting output strings
 *
 * @author Pavel Kozlov
 * @version 1.2
 */
class SearchTextOutputFormater {

    /**
     * Unique Unit Id attributes separator
     */
    static final String UNIT_ID_SEPARATOR = "~";

    /**
     * This method adds DU or DU component attribute and value pairs
     *
     * @param sb
     * @param tag
     * @param value
     * @param attrSeparator
     */
    protected static void addAttribute(
        StringBuffer sb,
        String tag,
        String value,
        String attrSeparator
    ) {
        if (value == null) value = "";
        sb.append(attrSeparator);
        sb.append(tag + "=" + value);
    }

    /**
     * This method adds Unique Unit Id attribute
     *
     * @param sb
     * @param s
     * @param addSeparator
     */
    protected static void addUnitIdPart(
        StringBuffer sb,
        String s,
        boolean addSeparator
    ) {
        if (s == null) {
            s = "";
        }
        sb.append(s);
        if (addSeparator) {
            sb.append(UNIT_ID_SEPARATOR);
        }
    }

    /**
     * This method returns DUUID as string
     *
     * @param sr - DU search result item
     * @param attrsInfo - collection of DUUID attributes info
     * @return string value
     * @throws SearchResultFormatException - possible exception
     */
    public static String getUnitIdAsString (
        UnitSearchResultXML sr, Map attrsInfo
    ) throws SearchResultFormatException {

        String result;
        String category;
        UnitIdXML unitId;

        if (sr instanceof PSESearchResultXML) {
            unitId = ((PSESearchResultXML) sr).getUnitId();
            if (((PSEUnitIdXML) unitId).isMarkerFlag()) {
                category = DocumentUnitIdConstants.PSM_CATEGORY;
            } else {
                category = DocumentUnitIdConstants.PSE_CATEGORY;
            }
        } else if (sr instanceof PSTSearchResultXML) {
            unitId = ((PSTSearchResultXML) sr).getUnitId();
            category = DocumentUnitIdConstants.PST_CATEGORY;
        } else if (sr instanceof SUPSearchResultXML) {
            unitId = ((SUPSearchResultXML) sr).getUnitId();
            category = DocumentUnitIdConstants.SUP_CATEGORY;
        } else if (sr instanceof SLESearchResultXML) {
            unitId = ((SLESearchResultXML) sr).getUnitId();
            category = DocumentUnitIdConstants.SLE_CATEGORY;
        } else if (sr instanceof LBESearchResultXML) {
            unitId = ((LBESearchResultXML) sr).getUnitId();
            category = DocumentUnitIdConstants.LBE_CATEGORY;
        } else if (sr instanceof HCDSearchResultXML) {
            unitId = ((HCDSearchResultXML) sr).getUnitId();
            category = DocumentUnitIdConstants.HCD_CATEGORY;
        } else {
            return "UNKNOWN AbstractSearchResultXMLContentType";
        }

        try {
            result = DocumentUnitIdFormatter.format(
                category, unitId, UNIT_ID_SEPARATOR, attrsInfo
            );
        } catch (DocumentUnitIdFormatException e) {
            throw new SearchResultFormatException(e);
        }

        return result;
    }

    /**
     * This method creates output string for DU components
     *
     * @param abstractSR - DU search result item
     * @param cf - component search result item
     * @param delimiter - output fields delimiter
     * @param attrsInfo - collection of DUUID attributes info
     *
     * @return output string
     *
     * @throws SearchResultFormatException - possible exception
     */
    static public String makeFileStringBuffer(
        UnitSearchResultXML abstractSR,
        ComponentFileXML cf,
        String delimiter,
        Map attrsInfo
    ) throws SearchResultFormatException {

        if (abstractSR == null) {
            throw new SearchResultFormatException(
                "Search result is empty."
            );
        }

        if (cf == null) {
            throw new SearchResultFormatException(
                "Component attributes of Search result are empty."
            );
        }

        StringBuffer dquSb = new StringBuffer();

        try {
            dquSb.append(getUnitIdAsString(abstractSR, attrsInfo));

            dquSb.append(getComponentAttrsAsString(cf));

            addAttribute(
                dquSb,
                "recordType",
                "FILE",
                delimiter
            );
            addAttribute(
                dquSb,
                "sequence",
                "" + cf.getSequence(),
                delimiter
            );
            addAttribute(
                dquSb,
                "attFlag",
                "" + cf.isAttFlag(),
                delimiter
            );
            addAttribute(
                dquSb,
                "attType",
                cf.getAttType(),
                delimiter
            );
            addAttribute(
                dquSb,
                "attId",
                cf.getAttId(),
                delimiter
            );
            addAttribute(
                dquSb,
                "type",
                cf.getType(),
                delimiter
            );
            addAttribute(
                dquSb,
                "actualPageCount",
                "" + cf.getActualPageCount(),
                delimiter
            );
            addAttribute(
                dquSb,
                "rotation",
                "" + cf.getRotation(),
                delimiter
            );
            addAttribute(
                dquSb,
                "size",
                "" + cf.getSize(),
                delimiter
            );

            String dateAsString = (
                cf.getLoadDate() != null
                ? cf.getLoadDate().getTime().toString()
                : ""
            );
            addAttribute(
                dquSb,
                "loadDate",
                dateAsString,
                delimiter
            );
        } catch (Exception e) {
            throw new SearchResultFormatException(e);
        }

        return dquSb.toString();
    }

    /**
     * This method creates output string for DUs
     *
     * @param abstractSR - UnitSearchResponseXML object
     * @param delimiter - attributes delimiter
     * @param attrsInfo - collection of DUUID attributes info
     * @return output string
     *
     * @throws SearchResultFormatException - possible exception
     */
    static public String makeUnitStringBuffer(
        UnitSearchResultXML abstractSR,
        String delimiter,
        Map attrsInfo
    ) throws SearchResultFormatException {

        if (abstractSR == null) {
            throw new SearchResultFormatException(
                "Search result is empty."
            );
        }

        StringBuffer dquSb = new StringBuffer();
        try {

            dquSb.append(getUnitIdAsString(abstractSR, attrsInfo));

            addAttribute(
                dquSb,
                "recordType",
                "UNIT",
                delimiter
            );

            addAttribute(
                dquSb,
                "disclosureLevel",
                abstractSR.getDisclosureLevel(),
                delimiter
            );

            addExportSensitivityAttr(abstractSR, dquSb, delimiter);

            addAttribute(
                dquSb,
                "frameCount",
                "" + abstractSR.getFrameCount(),
                delimiter
            );

            String dateAsString = (
                abstractSR.getLoadDate() != null
                ? abstractSR.getLoadDate().getTime().toString()
                : ""
            );
            addAttribute(
                dquSb,
                "loadDate",
                dateAsString,
                delimiter
            );
            addAttribute(
                dquSb,
                "isReadyForRetrieval",
                "" + abstractSR.isIsReadyForRetrieval(),
                delimiter
            );
            addAttribute(
                dquSb,
                "isCurrent",
                "" + abstractSR.isIsCurrent(),
                delimiter
            );
            addAttribute(
                dquSb,
                "isAccessible",
                "" + abstractSR.isIsAccessible(),
                delimiter
            );
            addAttribute(
                dquSb,
                "isComplete",
                "" + abstractSR.isIsCompleteDocument(),
                delimiter
            );
            addAttribute(
                dquSb,
                "isForceObsolescence",
                "" + abstractSR.isIsForceObsolescence(),
                delimiter
            );
            addAttribute(
                dquSb,
                "originatingSource",
                abstractSR.getOriginatingSource(),
                delimiter
            );
            addAttribute(
                dquSb,
                "dataAssemblyType",
                abstractSR.getDataAssemblyType(),
                delimiter
            );
            addAttribute(
                dquSb,
                "unitSystemId",
                "" + abstractSR.getUnitSystemId(),
                delimiter
            );

            dateAsString = (
                abstractSR.getModificationDate() != null
                ? abstractSR.getModificationDate().getTime().toString()
                : ""
            );
            addAttribute(
                dquSb,
                "modificationDate",
                dateAsString,
                delimiter
            );

            addAttribute(
                dquSb,
                "reverseComponentOrder",
                "" + abstractSR.isReverseComponentOrder(),
                delimiter
            );
            addAttribute(
                dquSb,
                "sensitivityLevel",
                abstractSR.getSensitivityLevel(),
                delimiter
            );
            addAttribute(
                dquSb,
                "totalNumberOfComponents",
                "" + abstractSR.getTotalNumberOfComponents(),
                delimiter
            );
            addAttribute(
                dquSb,
                "partType",
                abstractSR.getPartType(),
                delimiter
            );

            if (abstractSR instanceof SLESearchResultXML) {
                addSLEAdditionalAttributes(
                    dquSb,
                    (SLESearchResultXML) abstractSR,
                    delimiter
                );
            } else if (abstractSR instanceof SUPSearchResultXML) {
                addSUPAdditionalAttributes(
                    dquSb,
                    (SUPSearchResultXML) abstractSR,
                    delimiter
                );
            }
        } catch (Exception e) {
            throw new SearchResultFormatException(e);
        }

        return dquSb.toString();
    }

    /**
     * This method creates string represents DU component attributes.
     * Method is used while output string is creating and while downloading file
     * name is creating
     *
     * @param cf
     */
    static public String getComponentAttrsAsString (ComponentFileXML cf) {

        if (cf == null) {
            return "";
        }

        StringBuffer sb = new StringBuffer();

        if (cf.isAttFlag()) {
            addUnitIdPart(sb, null, true);
            addUnitIdPart(sb, cf.getAttType(), true);
            addUnitIdPart(sb, cf.getAttId(), false);
        } else {
            addUnitIdPart(sb, null, true);
            addUnitIdPart(sb, "PROPER", true);
            addUnitIdPart(sb, "" + cf.getSequence(), false);
        }

        return sb.toString();
    }

    /**
     * This method adds additional attributes into output string for SLE DUs
     *
     * @param dquSb
     * @param sleSearchResult
     * @param delimiter
     */
    static private void addSLEAdditionalAttributes(
        StringBuffer dquSb,
        SLESearchResultXML sleSearchResult,
        String delimiter
    ) {

		addAttribute(
            dquSb,
            "eoSerialNumber",
            sleSearchResult.getEoSerialNumber(),
            delimiter
        );
		addAttribute(
            dquSb,
            "project",
            sleSearchResult.getProject(),
            delimiter
        );
		addAttribute(
            dquSb,
            "title",
            sleSearchResult.getTitle(),
            delimiter
        );
		addAttribute(
            dquSb,
            "zoneRange",
            sleSearchResult.getZoneRange(),
            delimiter
        );
	}

    /**
     * This method adds additional attributes into output string for SUP DUs
     *
     * @param dquSb
     * @param supSearchResult
     * @param delimiter
     */
    static private void addSUPAdditionalAttributes(
        StringBuffer dquSb,
        SUPSearchResultXML supSearchResult,
        String delimiter
    ) {
		
		addAttribute(
            dquSb,
            "supplierName",
            supSearchResult.getSupplierName(),
            delimiter
        );
        addAttribute(
            dquSb,
            "isCageCodeBlocked",
            "" + supSearchResult.isCageCodeBlocked(),
            delimiter
        );
    }

    /**
     * This method adds ECCN/USML code into result string buffer.
     *
     * @param searchResp - UnitSearchResponseXML object
     * @param dquSb - result string buffer
     * @param delimiter - attributes delimiter
     */
    static private void addExportSensitivityAttr(
        UnitSearchResultXML searchResp,
        StringBuffer dquSb,
        String delimiter
    ) {
        if (
            searchResp instanceof SLESearchResultXML
            || searchResp instanceof LBESearchResultXML
            || searchResp instanceof HCDSearchResultXML
        ) {
            return;
        }

        ExportSensitivityXML expSens = searchResp.getExportSensitivity();

        if (expSens == null) {
            expSens = new ExportSensitivityXML("", null);
        }
        addAttribute(
            dquSb, "exportType", expSens.getLicenseType(), delimiter
        );

        String[] licenses = expSens.getLicenseCodes();
        StringBuffer sb = new StringBuffer();
        if (licenses != null && licenses.length > 0) {
            String licDelim = "";
            for (int i = 0; i < licenses.length; i++) {
                sb.append(licDelim).append(expSens.getLicenseCodes()[i]);
                licDelim = DocumentAttributes.EXPORT_SENS_LICENSES_DELIM;
            }
        }
        addAttribute(
            dquSb, "licenseCode", sb.toString(), delimiter
        );
    }

}

