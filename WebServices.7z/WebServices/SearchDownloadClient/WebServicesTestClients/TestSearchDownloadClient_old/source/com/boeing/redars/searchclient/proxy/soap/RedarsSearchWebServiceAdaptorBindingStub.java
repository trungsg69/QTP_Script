/**
 * RedarsSearchWebServiceAdaptorBindingStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package com.boeing.redars.searchclient.proxy.soap;

import org.apache.axis.transport.http.HTTPConstants;

import java.util.Hashtable;

public class RedarsSearchWebServiceAdaptorBindingStub extends org.apache.axis.client.Stub implements com.boeing.redars.searchclient.proxy.soap.RedarsSearchWebServiceAdaptor {

    private Hashtable m_cookieHeaders = new Hashtable();

    private java.util.Vector cachedSerClasses = new java.util.Vector();
    private java.util.Vector cachedSerQNames = new java.util.Vector();
    private java.util.Vector cachedSerFactories = new java.util.Vector();
    private java.util.Vector cachedDeserFactories = new java.util.Vector();

    static org.apache.axis.description.OperationDesc [] _operations;

    static {
        _operations = new org.apache.axis.description.OperationDesc[5];
        _initOperationDesc1();
    }

    private static void _initOperationDesc1(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("searchForDocumentsExternal");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "arg0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "WebServiceExternalDocumentRequestXML"), com.boeing.redars.searchclient.mappings.WebServiceExternalDocumentRequestXML.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "WebServiceDocumentSearchResponseXML"));
        oper.setReturnClass(com.boeing.redars.searchclient.mappings.WebServiceDocumentSearchResponseXML.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "return"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("searchForDocumentsExternalExt");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "arg0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "WebServiceExternalDocumentRequestExtXML"), com.boeing.redars.searchclient.mappings.WebServiceExternalDocumentRequestExtXML.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "WebServiceDocumentSearchResponseXML"));
        oper.setReturnClass(com.boeing.redars.searchclient.mappings.WebServiceDocumentSearchResponseXML.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "return"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[1] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("searchForDocumentsInternal");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "arg0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "WebServiceInternalDocumentRequestXML"), com.boeing.redars.searchclient.mappings.WebServiceInternalDocumentRequestXML.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "WebServiceDocumentSearchResponseXML"));
        oper.setReturnClass(com.boeing.redars.searchclient.mappings.WebServiceDocumentSearchResponseXML.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "return"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[2] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("searchForDocUnitsExternal");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "arg0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "ExternalDocumentRequestXML"), com.boeing.redars.searchclient.mappings.ExternalDocumentRequestXML.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "DocumentSearchResponseXML"));
        oper.setReturnClass(com.boeing.redars.searchclient.mappings.DocumentSearchResponseXML.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "return"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[3] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("searchForDocUnitsInternal");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "arg0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "InternalDocumentRequestXML"), com.boeing.redars.searchclient.mappings.InternalDocumentRequestXML.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "DocumentSearchResponseXML"));
        oper.setReturnClass(com.boeing.redars.searchclient.mappings.DocumentSearchResponseXML.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "return"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[4] = oper;

    }

    public RedarsSearchWebServiceAdaptorBindingStub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public RedarsSearchWebServiceAdaptorBindingStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

    public RedarsSearchWebServiceAdaptorBindingStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
        ((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.2");
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "AbstractSearchResultXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.AbstractSearchResultXML.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "ArrayOfAbstractSearchResultXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.AbstractSearchResultXML[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "AbstractSearchResultXML");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "ArrayOfComponentFileXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.ComponentFileXML[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "ComponentFileXML");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "ArrayOfExternalDocumentUnitItemExtXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.ExternalDocumentUnitItemExtXML[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "ExternalDocumentUnitItemExtXML");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "ArrayOfExternalDocumentUnitItemXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.ExternalDocumentUnitItemXML[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "ExternalDocumentUnitItemXML");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "ArrayOfExternalDocUnitItemXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.ExternalDocUnitItemXML[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "ExternalDocUnitItemXML");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "ArrayOfInternalDocumentUnitItemXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.InternalDocumentUnitItemXML[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "InternalDocumentUnitItemXML");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "ArrayOfInternalDocUnitItemXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.InternalDocUnitItemXML[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "InternalDocUnitItemXML");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "ArrayOfItemSearchStatusXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.ItemSearchStatusXML[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "ItemSearchStatusXML");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "ArrayOfSearchItemStatusXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.SearchItemStatusXML[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "SearchItemStatusXML");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "ArrayOfStringXML");
            cachedSerQNames.add(qName);
            cls = java.lang.String[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "ArrayOfUnitSearchResultXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.UnitSearchResultXML[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "UnitSearchResultXML");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "CompileListInfoXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.CompileListInfoXML.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "ComponentFileXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.ComponentFileXML.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "DocumentRequestStatusXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.DocumentRequestStatusXML.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "DocumentSearchResponseXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.DocumentSearchResponseXML.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "ExportSensitivityXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.ExportSensitivityXML.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "ExternalDocumentRequestXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.ExternalDocumentRequestXML.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "ExternalDocumentUnitItemExtXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.ExternalDocumentUnitItemExtXML.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "ExternalDocumentUnitItemXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.ExternalDocumentUnitItemXML.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "ExternalDocUnitItemXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.ExternalDocUnitItemXML.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "HCDSearchResponseXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.HCDSearchResponseXML.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "HCDSearchResultXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.HCDSearchResultXML.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "HCDUnitIdXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.HCDUnitIdXML.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "InternalDocumentRequestXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.InternalDocumentRequestXML.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "InternalDocumentUnitItemXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.InternalDocumentUnitItemXML.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "InternalDocUnitItemXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.InternalDocUnitItemXML.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "ItemSearchStatusXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.ItemSearchStatusXML.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "LBESearchResponseXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.LBESearchResponseXML.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "LBESearchResultXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.LBESearchResultXML.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "LBEUnitIdXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.LBEUnitIdXML.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "PSESearchResponseXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.PSESearchResponseXML.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "PSESearchResultXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.PSESearchResultXML.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "PSEUnitIdXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.PSEUnitIdXML.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "PSTSearchResponseXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.PSTSearchResponseXML.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "PSTSearchResultXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.PSTSearchResultXML.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "PSTUnitIdXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.PSTUnitIdXML.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "SearchInfoXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.SearchInfoXML.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "SearchItemStatusXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.SearchItemStatusXML.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "SLESearchResponseXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.SLESearchResponseXML.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "SLESearchResultXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.SLESearchResultXML.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "SLEUnitIdXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.SLEUnitIdXML.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "SUPSearchResponseXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.SUPSearchResponseXML.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "SUPSearchResultXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.SUPSearchResultXML.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "SUPUnitIdXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.SUPUnitIdXML.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "UnitIdXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.UnitIdXML.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "UnitSearchResponseXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.UnitSearchResponseXML.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "UnitSearchResultXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.UnitSearchResultXML.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "WebServiceDocumentSearchResponseXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.WebServiceDocumentSearchResponseXML.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "WebServiceExternalDocumentRequestExtXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.WebServiceExternalDocumentRequestExtXML.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "WebServiceExternalDocumentRequestXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.WebServiceExternalDocumentRequestXML.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/schemas/RedarsSearchWebService", "WebServiceInternalDocumentRequestXML");
            cachedSerQNames.add(qName);
            cls = com.boeing.redars.searchclient.mappings.WebServiceInternalDocumentRequestXML.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }

    protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call _call = super._createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            java.util.Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                java.lang.String key = (java.lang.String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            // All the type mapping information is registered
            // when the first call is made.
            // The type mapping information is actually registered in
            // the TypeMappingRegistry of the service, which
            // is the reason why registration is only needed for the first call.
            synchronized (this) {
                if (firstCall()) {
                    // must set encoding style before registering serializers
                    _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
                    _call.setEncodingStyle(org.apache.axis.Constants.URI_SOAP11_ENC);
                    for (int i = 0; i < cachedSerFactories.size(); ++i) {
                        java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
                        javax.xml.namespace.QName qName =
                                (javax.xml.namespace.QName) cachedSerQNames.get(i);
                        java.lang.Object x = cachedSerFactories.get(i);
                        if (x instanceof Class) {
                            java.lang.Class sf = (java.lang.Class)
                                 cachedSerFactories.get(i);
                            java.lang.Class df = (java.lang.Class)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                        else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
                            org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
                                 cachedSerFactories.get(i);
                            org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                    }
                }
            }
            return _call;
        }
        catch (java.lang.Throwable _t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
        }
    }

    public void setCookieHeaders(Hashtable cookieHeaders) {

        if (cookieHeaders == null) {
            m_cookieHeaders = new Hashtable();
        } else {
            m_cookieHeaders = cookieHeaders;
        }
    }

    public com.boeing.redars.searchclient.mappings.WebServiceDocumentSearchResponseXML searchForDocumentsExternal(com.boeing.redars.searchclient.mappings.WebServiceExternalDocumentRequestXML arg0) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[0]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/services/RedarsSearch", "searchForDocumentsExternal"));

        setRequestHeaders(_call);
        setAttachments(_call);
        _call.setProperty(HTTPConstants.REQUEST_HEADERS, m_cookieHeaders);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {arg0});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.boeing.redars.searchclient.mappings.WebServiceDocumentSearchResponseXML) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.boeing.redars.searchclient.mappings.WebServiceDocumentSearchResponseXML) org.apache.axis.utils.JavaUtils.convert(_resp, com.boeing.redars.searchclient.mappings.WebServiceDocumentSearchResponseXML.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.boeing.redars.searchclient.mappings.WebServiceDocumentSearchResponseXML searchForDocumentsExternalExt(com.boeing.redars.searchclient.mappings.WebServiceExternalDocumentRequestExtXML arg0) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[1]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/services/RedarsSearch", "searchForDocumentsExternalExt"));

        setRequestHeaders(_call);
        setAttachments(_call);
        _call.setProperty(HTTPConstants.REQUEST_HEADERS, m_cookieHeaders);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {arg0});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.boeing.redars.searchclient.mappings.WebServiceDocumentSearchResponseXML) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.boeing.redars.searchclient.mappings.WebServiceDocumentSearchResponseXML) org.apache.axis.utils.JavaUtils.convert(_resp, com.boeing.redars.searchclient.mappings.WebServiceDocumentSearchResponseXML.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.boeing.redars.searchclient.mappings.WebServiceDocumentSearchResponseXML searchForDocumentsInternal(com.boeing.redars.searchclient.mappings.WebServiceInternalDocumentRequestXML arg0) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[2]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/services/RedarsSearch", "searchForDocumentsInternal"));

        setRequestHeaders(_call);
        setAttachments(_call);
        _call.setProperty(HTTPConstants.REQUEST_HEADERS, m_cookieHeaders);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {arg0});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.boeing.redars.searchclient.mappings.WebServiceDocumentSearchResponseXML) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.boeing.redars.searchclient.mappings.WebServiceDocumentSearchResponseXML) org.apache.axis.utils.JavaUtils.convert(_resp, com.boeing.redars.searchclient.mappings.WebServiceDocumentSearchResponseXML.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.boeing.redars.searchclient.mappings.DocumentSearchResponseXML searchForDocUnitsExternal(com.boeing.redars.searchclient.mappings.ExternalDocumentRequestXML arg0) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[3]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/services/RedarsSearch", "searchForDocUnitsExternal"));

        setRequestHeaders(_call);
        setAttachments(_call);
        _call.setProperty(HTTPConstants.REQUEST_HEADERS, m_cookieHeaders);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {arg0});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.boeing.redars.searchclient.mappings.DocumentSearchResponseXML) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.boeing.redars.searchclient.mappings.DocumentSearchResponseXML) org.apache.axis.utils.JavaUtils.convert(_resp, com.boeing.redars.searchclient.mappings.DocumentSearchResponseXML.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.boeing.redars.searchclient.mappings.DocumentSearchResponseXML searchForDocUnitsInternal(com.boeing.redars.searchclient.mappings.InternalDocumentRequestXML arg0) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[4]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://namespace.web.boeing.com/engineering/redars/services/RedarsSearch", "searchForDocUnitsInternal"));

        setRequestHeaders(_call);
        setAttachments(_call);
        _call.setProperty(HTTPConstants.REQUEST_HEADERS, m_cookieHeaders);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {arg0});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.boeing.redars.searchclient.mappings.DocumentSearchResponseXML) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.boeing.redars.searchclient.mappings.DocumentSearchResponseXML) org.apache.axis.utils.JavaUtils.convert(_resp, com.boeing.redars.searchclient.mappings.DocumentSearchResponseXML.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

}
