/*
 * @(#)SearchItemPopulator.java
 *
 * Copyright (c) 2006 The Boeing Company. All Rights Reserved.
 */

package com.boeing.redars.searchclient;

import com.boeing.redars.unitidparser.parser.DocumentUnitIdParser;
import com.boeing.redars.unitidparser.config.DocumentUnitIdConstants;
import com.boeing.redars.unitidparser.except.DocumentUnitIdParseException;
import com.boeing.redars.searchclient.mappings.*;
import com.boeing.redars.inputpaging.CollectionObject;

import java.util.StringTokenizer;
import java.util.Map;

/**
 * This class represents help object, that creates valid request item. This
 * result item will be used during search method invocation
 *
 * @author Pavel Kozlov
 * @version 1.0
 */
public class SearchItemPopulator {

    /**
     * Defaulr delimiter for input line attributes (<TAB>)
     */
    private String m_argSeparator = "\t";

    /**
     * unit id parser, that parse DU id from input line
     */
    private DocumentUnitIdParser m_parser = new DocumentUnitIdParser();

    /**
     * This method determine additional criteria for search and return
     * warning message (if value for any attribute is not valid,
     * or any attribute is invalid)
     * Main function of this method is to fill fields of
     * AdditionalSearchAttributes object.
     *
     * @param inStr
     * @param attrs
     * @return warning message
     */
    private String getAdditionalAttrs (
        String inStr,
        AdditionalSearchAttributes attrs
    ) {

        String warningMsg = "";
        StringTokenizer st = new StringTokenizer(inStr, m_argSeparator);

        while (st.hasMoreElements()) {
            String jk = st.nextToken();

            if (jk.equals("includeHistory=true")) {
                attrs.getSearchInfo().setIncludeHistory(true);
            } else if (jk.equals("includeHistory=false")) {
                attrs.getSearchInfo().setIncludeHistory(false);
            } else if (jk.equals("partialDocumentNumber=true")) {
                attrs.getSearchInfo().setPartialDocumentNumber(true);
            } else if (jk.equals("partialDocumentNumber=false")) {
                attrs.getSearchInfo().setPartialDocumentNumber(false);
            } else if (jk.equals("provideFileArray=true")) {
                attrs.setProvideFileArray(true);
            } else if (jk.equals("provideFileArray=false")) {
                attrs.setProvideFileArray(false);
            } else if (jk.equals("readyForRetrieval=true")) {
                attrs.setReadyForRetrieval("true");
            } else if (jk.equals("readyForRetrieval=false")) {
                attrs.setReadyForRetrieval("false");
            } else if (jk.equals("completeStatus=true")) {
                attrs.setCompleteStatus("true");
            } else if (jk.equals("completeStatus=false")) {
                attrs.setCompleteStatus("false");
            } else if (jk.startsWith("maxItems=")) {
                StringTokenizer stjk = new StringTokenizer(jk, "=");
                String tag = stjk.nextToken();
                if (!stjk.hasMoreElements()) {
                    warningMsg =
                        warningMsg
                        + "no value given for maxItems tag, ignored; ";

                } else {
                    String value = stjk.nextToken();
                    try {
                        attrs.getSearchInfo().setMaxItems(Integer.parseInt(value));
                    } catch (NumberFormatException e) {
                        warningMsg =
                            warningMsg
                            + "wrong value '"
                            + value
                            + "' given for maxItems tag, ignored; ";
                    }
                }
            } else if (jk.startsWith("startFrom=")) {
                StringTokenizer stjk = new StringTokenizer(jk, "=");
                String tag = stjk.nextToken();
                if (!stjk.hasMoreElements()) {
                    warningMsg =
                        warningMsg
                        + "no value given for startFrom tag, ignored; ";
                } else {
                    String value = stjk.nextToken();
                    try {
                        attrs.getSearchInfo().setStartFrom(Integer.parseInt(value));
                    } catch (NumberFormatException e) {
                        warningMsg =
                            warningMsg
                            + "wrong value '"
                            + value
                            + "' given for startFrom tag, ignored; ";
                    }
                }
            } else {
                warningMsg =
                    warningMsg
                    + "ignoring text <"
                    + jk
                    + "> ";
            }
        }

        return warningMsg;
    }

    /**
     * This method creates internal search request item, and, if it is valid,
     * put it into new Collection Object
     *
     * @param inStr
     * @return SearchCollectionObject
     * @throws InputParseException
     */
    public SearchCollectionObject createIntItem(String inStr)
        throws InputParseException {

        Map attributes = null;
        InternalDocUnitItemXML item = new InternalDocUnitItemXML();
        SearchCollectionObject itemDetails =
            new SearchCollectionObject(inStr, item);

        StringTokenizer st = new StringTokenizer(inStr, m_argSeparator);
        if (!st.hasMoreElements()) {
            throw new InputParseException(
                "no document unit id in <" + inStr + ">"
            );
        }

        String uid;

        try {
            uid = st.nextToken();
            attributes = m_parser.parse(uid);

            //check for type of unitId (is this system id?)
            if (
                !DocumentUnitIdConstants.DOC_UNIT_INTERNAL_ID_TYPE_VALUE.equals(
                    attributes.get(DocumentUnitIdConstants.DOC_UNIT_ID_TYPE_ATTR)
                )
            ) {
                 throw new InputParseException(
                     "wrong document unit system id in <" + inStr + ">"
                 );
            }

            item.setUnitSystemId(
                (
                    (Long) attributes.get(
                        DocumentUnitIdConstants.DOC_UNIT_SYSTEM_ID_ATTR
                    )
                ).longValue()
            );

        } catch (DocumentUnitIdParseException pe) {
            throw new InputParseException(pe.getMessage());
        }

        // get additional query attributes
        AdditionalSearchAttributes attrs = new AdditionalSearchAttributes();
        String attrStr = "";
        if (st.hasMoreElements()) {
            attrStr = inStr.substring(uid.length() + 1);
        }
        String warningMsg = getAdditionalAttrs(
            attrStr,
            attrs
        );

        // BEGIN 2370
        if (attrs.getReadyForRetrieval() != null) {
            warningMsg = warningMsg
                + "readyForRetrieval attribute is applicable "
                + "only in External Search; ";
        }
        // END 2370

        item.setSearchInfo(attrs.getSearchInfo());
        item.setProvideFileArray(attrs.isProvideFileArray());

        itemDetails.setParseWarning(warningMsg);
        return itemDetails;
    }

    /**
     * This method creates external search request item, and, if it is valid,
     * put it into new Collection Object
     *
     * @param inStr
     * @return SearchCollectionObject
     * @throws InputParseException
     */
    public SearchCollectionObject createExtItem(String inStr)
        throws InputParseException {

        Map attributes = null;
        ExternalDocUnitItemXML item = new ExternalDocUnitItemXML();
        SearchCollectionObject itemDetails =
            new SearchCollectionObject(inStr, item);

        StringTokenizer st = new StringTokenizer(inStr, m_argSeparator);
        if (!st.hasMoreElements()) {
            throw new InputParseException(
                "no document unit id in <" + inStr + ">"
            );
        }

        UnitIdXML unitId = null;
        String uid;

        try {
            uid = st.nextToken();
            attributes = m_parser.parse(uid);

            //check for type of unitId (is this unique id?)
            if (
                !DocumentUnitIdConstants.DOC_UNIT_EXTERNAL_ID_TYPE_VALUE.equals(
                    attributes.get(DocumentUnitIdConstants.DOC_UNIT_ID_TYPE_ATTR)
                )
            ) {
                 throw new InputParseException(
                     "wrong document unit id in <" + inStr + ">"
                 );
            }
            //prepare unitId parameter for item
            String category = (String) attributes.get(
                DocumentUnitIdConstants.DOC_UNIT_CATEGORY_ATTR
            );

            if (DocumentUnitIdConstants.PSE_CATEGORY.equals(category)) {
                unitId = new PSEUnitIdXML();
                ((PSEUnitIdXML) unitId).setId(
                    (String) attributes.get(
                       DocumentUnitIdConstants.DOC_UNIT_SUB_ID_ATTR
                   )
                );
                ((PSEUnitIdXML) unitId).setMarkerFlag(false);
                ((PSEUnitIdXML) unitId).setRevision(
                    (String) attributes.get(
                       DocumentUnitIdConstants.DOC_UNIT_REVISION_ATTR
                   )
                );
            } else if (DocumentUnitIdConstants.PSM_CATEGORY.equals(category)) {
                unitId = new PSEUnitIdXML();
                ((PSEUnitIdXML) unitId).setId(
                    (String) attributes.get(
                       DocumentUnitIdConstants.DOC_UNIT_SUB_ID_ATTR
                   )
                );
                ((PSEUnitIdXML) unitId).setMarkerFlag(true);
                ((PSEUnitIdXML) unitId).setRevision(
                    (String) attributes.get(
                       DocumentUnitIdConstants.DOC_UNIT_REVISION_ATTR
                   )
                );
            } else if (DocumentUnitIdConstants.PST_CATEGORY.equals(category)) {
                unitId = new PSTUnitIdXML();
                ((PSTUnitIdXML) unitId).setId(
                    (String) attributes.get(
                       DocumentUnitIdConstants.DOC_UNIT_SUB_ID_ATTR
                   )
                );
                ((PSTUnitIdXML) unitId).setRevision(
                    (String) attributes.get(
                       DocumentUnitIdConstants.DOC_UNIT_REVISION_ATTR
                   )
                );
            } else if (DocumentUnitIdConstants.LBE_CATEGORY.equals(category)) {
                unitId = new LBEUnitIdXML();
                ((LBEUnitIdXML) unitId).setDashNumber(
                    (String) attributes.get(
                       DocumentUnitIdConstants.DOC_UNIT_DASH_NUMBER_ATTR
                   )
                );
                ((LBEUnitIdXML) unitId).setId(
                    (String) attributes.get(
                       DocumentUnitIdConstants.DOC_UNIT_SUB_ID_ATTR
                   )
                );
                ((LBEUnitIdXML) unitId).setReissue(
                    (String) attributes.get(
                       DocumentUnitIdConstants.DOC_UNIT_REISSUE_ATTR
                    )
                );
                ((LBEUnitIdXML) unitId).setRevision(
                    (String) attributes.get(
                       DocumentUnitIdConstants.DOC_UNIT_REVISION_ATTR
                   )
                );
            } else if (DocumentUnitIdConstants.SLE_CATEGORY.equals(category)) {
                unitId = new SLEUnitIdXML();
                ((SLEUnitIdXML) unitId).setId(
                    (String) attributes.get(
                        DocumentUnitIdConstants.DOC_UNIT_SUB_ID_ATTR
                    )
                );
                ((SLEUnitIdXML) unitId).setReissue(
                    (String) attributes.get(
                        DocumentUnitIdConstants.DOC_UNIT_REISSUE_ATTR
                    )
                );
                ((SLEUnitIdXML) unitId).setRevision(
                    (String) attributes.get(
                        DocumentUnitIdConstants.DOC_UNIT_REVISION_ATTR
                    )
                );
            } else if (DocumentUnitIdConstants.SUP_CATEGORY.equals(category)) {
                unitId = new SUPUnitIdXML();
                ((SUPUnitIdXML) unitId).setCageCode(
                    (String) attributes.get(
                        DocumentUnitIdConstants.DOC_UNIT_CAGE_CODE_ATTR
                    )
                );
                ((SUPUnitIdXML) unitId).setId(
                    (String) attributes.get(
                        DocumentUnitIdConstants.DOC_UNIT_SUB_ID_ATTR
                    )
                );
                ((SUPUnitIdXML) unitId).setModel(
                    (String) attributes.get(
                        DocumentUnitIdConstants.DOC_UNIT_MODEL_ATTR
                    )
                );
                ((SUPUnitIdXML) unitId).setRevision(
                    (String) attributes.get(
                        DocumentUnitIdConstants.DOC_UNIT_REVISION_ATTR
                    )
                );
                ((SUPUnitIdXML) unitId).setVolumePartPage(
                    (String) attributes.get(
                        DocumentUnitIdConstants.DOC_UNIT_VOLUME_PART_ATTR
                    )
                );
            } else if (DocumentUnitIdConstants.HCD_CATEGORY.equals(category)) {
                unitId = new HCDUnitIdXML();
                ((HCDUnitIdXML) unitId).setId(
                    (String) attributes.get(
                        DocumentUnitIdConstants.DOC_UNIT_SUB_ID_ATTR
                    )
                );
                ((HCDUnitIdXML) unitId).setOwnerCompanyCode(
                    (String) attributes.get(
                        DocumentUnitIdConstants.DOC_UNIT_OWNER_COMPANY_CODE_ATTR
                    )
                );
                ((HCDUnitIdXML) unitId).setRevision(
                    (String) attributes.get(
                        DocumentUnitIdConstants.DOC_UNIT_REVISION_ATTR
                    )
                );
            }
            unitId.setBaseDocumentNumber(
                (String) attributes.get(
                    DocumentUnitIdConstants.DOC_UNIT_BASE_NUMBER_ATTR
                )
            );
            unitId.setUnitType(
                (String) attributes.get(
                    DocumentUnitIdConstants.DOC_UNIT_TYPE_ATTR
                )
            );
        } catch (DocumentUnitIdParseException pe) {
            throw new InputParseException(pe.getMessage());
        }
        //set unit id for item
        item.setUnitId(unitId);

        // get additional query attributes
        AdditionalSearchAttributes attrs = new AdditionalSearchAttributes();
        String attrStr = "";
        if (st.hasMoreElements()) {
            attrStr = inStr.substring(uid.length() + 1);
        }
        String warningMsg = getAdditionalAttrs(
            attrStr,
            attrs
        );

        item.setSearchInfo(attrs.getSearchInfo());
        item.setProvideFileArray(attrs.isProvideFileArray());
        item.setReadyForRetrieval(attrs.getReadyForRetrieval());
        item.setCompleteStatus(attrs.getCompleteStatus());

        itemDetails.setParseWarning(warningMsg);
        return itemDetails;
    }

    /**
     * this method sets delimiter for input line attributes
     * (now available '|' and <TAB>(default))
     * @param argSeparator
     */
    public void setArgSeparator(String argSeparator) {
        m_argSeparator = argSeparator;
    }
}
