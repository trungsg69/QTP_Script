/*
 * @(#)DocDownloader.java
 * Copyright (c) 2006-2011 The Boeing Company. All Rights Reserved.
 */

package com.boeing.redars.searchclient;
import com.boeing.redars.utils.StringHelper;

import org.apache.axis.transport.http.HTTPConstants;
import org.apache.log4j.Logger;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLDecoder;
import java.util.*;

/**
 * This class provides method for components downloading
 */
public class DocDownloader {

    /**
     * Reading buffer size
     */
    private static final int BUF_SIZE = 2048;

    /**
     * This field represents decode schema
     */
    private static final String DECODE_SCHEMA = "UTF-8";

    /**
     * This method downloads component.
     *
     * @param stringUrl
     * @param exportFileName
     * @param baseDir
     * @param unitDir
     * @param basicAuth
     * @param out
     */
    public static boolean downloadUnitComponent(
        String stringUrl,
        String exportFileName,
        String baseDir,
        String unitDir,
        String basicAuth,
        PrintStream out,
        Hashtable cookieFields
    ) {

        boolean result = false;
        HttpURLConnection conn = null;
        FileOutputStream fos = null;
        BufferedWriter bw = null;
        HttpURLConnection.setFollowRedirects(true);

        try {

            URL url = new URL(stringUrl);
            try {
                conn = (HttpURLConnection) url.openConnection();
            } catch (IOException e) {
                throw new LoggedException(
                    "Open connection error.",
                    conn,
                    out
                );
            }

            conn.setUseCaches(false);
            conn.setRequestProperty(
                HTTPConstants.HEADER_AUTHORIZATION,
                basicAuth
            );

            if (cookieFields != null) {
                Enumeration keys = cookieFields.keys();
                while (keys.hasMoreElements()) {
                    String headerName = (String) keys.nextElement();
                    String headerValue = (String) cookieFields.get(headerName);
                    if (headerValue != null && headerValue.length() != 0) {
                        conn.setRequestProperty(headerName, headerValue);
                    }
                }
            }
            Logger logger = Logger.getLogger (DocDownloader.class);
            out.println("Connecting to " + stringUrl);
            logger.debug("Connecting to " + stringUrl);
            try {

                Map headers = conn.getRequestProperties();
                Set names = headers.keySet();
                logger.debug("Next HTTP headers are used:");
                for (Iterator iter = names.iterator(); iter.hasNext(); ) {
                    String name = (String) iter.next();
                    Object value = headers.get(name);
                    logger.debug(name + ": " + value);
                }

                conn.connect();
                String errorMsg = conn.getHeaderField(
                    SearchDownloadConstants.WS_DOWNLOAD_ERROR_KEY
                );
                if (!StringHelper.isEmptyString(errorMsg)) {
                    errorMsg = URLDecoder.decode(errorMsg, DECODE_SCHEMA);
                    final String msg = (
                        "Error occurred during request processing: "
                        + errorMsg
                    );
                    out.println(msg);
                    logger.debug(msg);
                } else {
                    errorMsg = "Connect error.";
                }
                if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
                    throw new LoggedException(
                        errorMsg,
                        conn,
                        out
                    );
                }
                out.println("Connected.");
                logger.debug("Connected.");
                logger.debug("Next HTTP headers are received:");
                headers = conn.getHeaderFields();
                names = headers.keySet();
                for (Iterator iter = names.iterator(); iter.hasNext(); ) {
                    String name = (String) iter.next();
                    Object value = headers.get(name);
                    logger.debug(name + ": " + value);
                }
            } catch (LoggedException le) {

            } catch (IOException e) {
                logger.error("Connection error.", e);
                e.printStackTrace(out);
                throw new LoggedException (
                    "Connect error.",
                    conn,
                    out
                );
            }

            InputStream is = null;

            byte[] buffer = new byte[BUF_SIZE];
            StringBuffer sb = new StringBuffer(baseDir);
            if (sb.charAt(sb.length() - 1) != File.separatorChar) {
                sb.append(File.separator);
            }
            sb.append(unitDir);
            if (sb.charAt(sb.length() - 1) != File.separatorChar) {
                sb.append(File.separator);
            }
            // Create containing directory
            File directory = new File(sb.toString());
            directory.mkdirs();

            // Download content
            String fullFileName = sb.toString() + exportFileName;
            try {
                if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    try {
                        is = conn.getInputStream();
                    } catch (IOException e) {
                        throw new LoggedException (
                            "Input stream error.",
                            conn,
                            out
                        );
                    }

                    if (is == null) {
                        throw new LoggedException (
                            "Input stream open error",
                            out
                        );
                    }
                    try {
                        fos = new FileOutputStream(fullFileName);
                    } catch (FileNotFoundException e) {

                        throw new LoggedException(
                            "Output file creation error: ",
                            e,
                            out
                        );
                    }

                    out.print("Downloading to " + fullFileName);

                    while (true) {
                        int read;
                        try {
                            read = is.read(buffer);
                        } catch (IOException e) {
                            throw new LoggedException(
                                "Data read error: " + e.getMessage(),
                                out
                            );
                        }

                        out.print('.');

                        if (read == -1) {
                            break;
                        }
                        try {
                            fos.write(buffer, 0, read);
                        } catch (IOException e) {
                            out.println();
                            throw new LoggedException(
                                "File data write error: " + e.getMessage(),
                                out
                            );
                        }
                    }

                    result = true;
                    out.println();
                    out.println("Done!");
                    out.println();
                }
            } catch (IOException e) {

            }
            // Save headers
            String auxFileName;
            try {
                auxFileName =
                    sb.toString()
                    + String.valueOf(conn.getResponseCode())
                    + " "
                    + exportFileName + ".txt";
            } catch (IOException e) {
                throw new LoggedException(
                    "Output file name read error:" + e.getMessage(),
                    out
                );
            }

            try {
                bw = new BufferedWriter(new FileWriter(auxFileName));
            } catch (IOException e) {

                e.printStackTrace(out);
                //e.printStackTrace();
            }

            // Some implemetations of HttpURLConnection may treat
            // the 0th header field as special, i.e. as the status
            // line returned by the HTTP server. So we write status line
            // manually
            //
            String statusLine;
            try {
                statusLine = (
                    String.valueOf(conn.getResponseCode()) + " " +
                    conn.getResponseMessage()
                );
            } catch (IOException e) {
                out.println();
                throw new LoggedException(
                    "Data read from connection error:" + e.getMessage(),
                    out
                );
            }
            try {
               bw.write(statusLine);
               bw.newLine();
            } catch (IOException e) {
               throw new LoggedException(
                   "File write error: " + e.getMessage(),
                   out
               );
            }

            int field = 1;
            while (true) {
                String key = conn.getHeaderFieldKey(field);
                if (key == null) {
                    break;
                }
                // try to decode header value
                String value;
                try {
                    value = URLDecoder.decode(
                        conn.getHeaderField(field),
                        DECODE_SCHEMA
                    );
                } catch (UnsupportedEncodingException e) {
                    value = conn.getHeaderField(field);
                }
                try {
                    bw.write(key + ": " + value);
                    bw.newLine();
                } catch (IOException e) {
                    throw new LoggedException(
                        "File write error: " + e.getMessage(),
                        out
                    );
                }
                field++;
            }

            try {
                if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
                    bw.newLine();
                    is = conn.getErrorStream();
                    int len;
                    while ((len = is.read(buffer)) >= 0) {
                        String part = new String(buffer, 0, len);
                        bw.write(part);
                    }

                }

            } catch (Exception e) {

            }
        }
        catch(MalformedURLException	ex) {
            out.println("Malformed URL: " + ex.getMessage());
        }
        catch (LoggedException e) {
            out.println("Failed.");
        }
        finally {
            if (conn != null) {
                conn.disconnect();
            }
            try {
                if (fos != null) {
                    fos.close();
                }
                if (bw != null) {
                    bw.close();
                }
            }
            catch (IOException ex) {
            }
        }

        return result;
    }

}


