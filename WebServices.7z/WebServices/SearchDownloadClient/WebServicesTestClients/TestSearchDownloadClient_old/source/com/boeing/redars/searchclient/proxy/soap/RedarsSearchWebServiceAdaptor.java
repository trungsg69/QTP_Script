/**
 * RedarsSearchWebServiceAdaptor.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.3 Oct 05, 2005 (05:23:37 EDT) WSDL2Java emitter.
 */

package com.boeing.redars.searchclient.proxy.soap;

public interface RedarsSearchWebServiceAdaptor extends java.rmi.Remote {
    public com.boeing.redars.searchclient.mappings.WebServiceDocumentSearchResponseXML searchForDocumentsExternal(com.boeing.redars.searchclient.mappings.WebServiceExternalDocumentRequestXML arg0) throws java.rmi.RemoteException;
    public com.boeing.redars.searchclient.mappings.WebServiceDocumentSearchResponseXML searchForDocumentsExternalExt(com.boeing.redars.searchclient.mappings.WebServiceExternalDocumentRequestExtXML arg0) throws java.rmi.RemoteException;
    public com.boeing.redars.searchclient.mappings.WebServiceDocumentSearchResponseXML searchForDocumentsInternal(com.boeing.redars.searchclient.mappings.WebServiceInternalDocumentRequestXML arg0) throws java.rmi.RemoteException;
    public com.boeing.redars.searchclient.mappings.DocumentSearchResponseXML searchForDocUnitsExternal(com.boeing.redars.searchclient.mappings.ExternalDocumentRequestXML arg0) throws java.rmi.RemoteException;
    public com.boeing.redars.searchclient.mappings.DocumentSearchResponseXML searchForDocUnitsInternal(com.boeing.redars.searchclient.mappings.InternalDocumentRequestXML arg0) throws java.rmi.RemoteException;
}
