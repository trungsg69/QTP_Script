/*
 * @(#)ResponceStatusKeys.java  1.0
 *
 * Copyright (c) 2006 The Boeing Company All rights reserved.
 */

package com.boeing.redars.searchclient;

/**
 * This class contains constants for determining responce statuses
 *
 * @author Pavel Kozlov
 * @version 1.0
 */
public class ResponseStatusKeys {

    public static int SEARCH_CODE_IGNORED = -100;
    public static int SEARCH_CODE_OK = 0;

}
