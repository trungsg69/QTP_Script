/*
 * @(#)AdditionalSearchAttributes.java
 *
 * Copyright (c) 2006 The Boeing Company. All Rights Reserved.
 */

package com.boeing.redars.searchclient;

import com.boeing.redars.searchclient.mappings.SearchInfoXML;
import com.boeing.redars.searchclient.mappings.CompileListInfoXML;

/**
 * This class is container for additional criterias of search
 *
 * @author Pavel Kozlov
 * @version 1.0
 */
public class AdditionalSearchAttributes {
    /**
     * Search info field
     */
    private SearchInfoXML m_searchInfo = new SearchInfoXML();
    /**
     * Compile List field
     */
    private CompileListInfoXML m_compileListInfo = new CompileListInfoXML();
    /**
     * provide file array property
     */
    private boolean m_provideFileArray = false;
    /**
     * ready for retrival property (can be null)
     */
    private String m_readyForRetrieval = null;

    /**
     * COMPLETE_DOCUMENT search condition value (can be null)
     */
    private String m_completeStatus = null;

    /**
     * Constructor.
     *
     * When object will be created, default values for all properties
     * will be created
     */
    public AdditionalSearchAttributes() {

        // set default values
        m_searchInfo.setIncludeHistory(true);
        m_searchInfo.setPartialDocumentNumber(false);
        m_searchInfo.setMaxItems(10);
        m_searchInfo.setStartFrom(1);

        // Set default value large enough
        m_compileListInfo.setFirstComponentSequenceNumber(1);
        m_compileListInfo.setLastComponentSequenceNumber(1000);

        m_provideFileArray = false;
    }

    /**
     * Getter for search info field
     * @return search info
     */
    public SearchInfoXML getSearchInfo() {
        return m_searchInfo;
    }

    /**
     * Setter for search info field
     * @param searchInfo
     */
    public void setSearchInfo(SearchInfoXML searchInfo) {
        m_searchInfo = searchInfo;
    }

    /**
     * Getter for compile list field
     *
     * @return compile list
     */
    public CompileListInfoXML getCompileListInfo() {
        return m_compileListInfo;
    }

    /**
     * Setter for compile list field
     *
     * @param compileListInfo
     */
    public void setCompileListInfo(CompileListInfoXML compileListInfo) {
        m_compileListInfo = compileListInfo;
    }

    /**
     * Getter for provide file array property
     *
     * @return boolean flag
     */
    public boolean isProvideFileArray() {
        return m_provideFileArray;
    }

    /**
     * Setter for provide file array property
     *
     * @param provideFileArray
     */
    public void setProvideFileArray(boolean provideFileArray) {
        m_provideFileArray = provideFileArray;
    }

    /**
     * Getter for ready for retrival property
     *
     * @return string value
     */
    public String getReadyForRetrieval() {
        return m_readyForRetrieval;
    }

    /**
     * Setter for for ready for retrival property
     *
     * @param readyForRetrieval
     */
    public void setReadyForRetrieval(String readyForRetrieval) {
        m_readyForRetrieval = readyForRetrieval;
    }

    /**
     * Getter for completeStatus field
     *
     * @return string represented value (can be null)
     */
    public String getCompleteStatus() {
        return m_completeStatus;
    }

    /**
     * Setter for completeStatus field
     *
     * @param completeStatus - string value (can be null)
     */
    public void setCompleteStatus(String completeStatus) {
        m_completeStatus = completeStatus;
    }
}
