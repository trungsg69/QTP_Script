/*
 * @(#)SearchCollectionObject.java  1.0
 *
 * Copyright (c) 2006 The Boeing Company All rights reserved.
 */

package com.boeing.redars.searchclient;

import com.boeing.redars.inputpaging.CollectionObject;

/**
 * This class extends CollectionObject class, contain parse warning message field
 *
 * @author Pavel Kozlov
 * @version 1.0
 */
public class SearchCollectionObject extends CollectionObject {

    /**
     * parse warning message field
     */
    private String m_parseWarning = null;

    /**
     * constructor
     */
    public SearchCollectionObject(String inLine, Object requestItem) {
        super(inLine, requestItem);
    }
    
    /**
     * Getter for parse warning message field
     * @return arse warning message
     */
    public String getParseWarning() {
        return m_parseWarning;
    }

    /**
     * Setter for parse warning message field
     * @param parseWarning
     */
    public void setParseWarning(String parseWarning) {
        m_parseWarning = parseWarning;
    }
}
