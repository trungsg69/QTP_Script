/*
 * @(#)LoggedException.java
 *
 * Copyright (c) 2006 The Boeing Company. All Rights Reserved.
 */

package com.boeing.redars.searchclient;

import java.io.IOException;
import java.io.PrintStream;
import java.net.HttpURLConnection;


public class LoggedException extends Exception {
    /**
     * serial version id value
     */
    private static final long serialVersionUID = 4496989030531964487L;
    
    /**
     * Creates exception with http description.
     * @param msg error message 
     * @param conn http connection
     * @param out stream to log
     */
    public LoggedException (
            String msg, 
            HttpURLConnection conn,
            PrintStream out
    ) {
        if (conn == null) {
            out.println(msg + " HTTP Connection does not exist.");
            return; 
        }
        try {
            out.println (
                msg    
                + " (HTTP response: "
                + conn.getResponseCode() 
                + ", "
                + conn.getResponseMessage()
                + ")"
            );
        } catch (IOException e) {
            out.println(msg + " HTTP status report error.");
        }
    }
    
    /**
     * creates exception from inherited exception 
     * @param e inherited exception
     * @param out stream for logging
     */
    public LoggedException (String msg, Exception e, PrintStream out) {
        out.println(msg+ ": " + e.getMessage());
    }
        
    /**
     * creates exception from inherited exception
     * @param msg exception message
     * @param out stream for logging
     */
    public LoggedException(String msg, PrintStream out) {
        out.println(msg);
    }
}
