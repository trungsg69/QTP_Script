########################
# Billing Report Script.
########################

# Use absolute path
. /home/redars/Trung_report/BatchReports/v24.1.0.12/setEnv.sh

$REDARS_JAVA_HOME/bin/java -Dbatch_reports_dir=$BASEDIR -classpath $REDARS_CLASSPATH com.boeing.redars.batchreport.BillingReport BillingReport.Filename=${OUTPUTDIR}/nextgen.billing. GuaranteePeriod=0 >> $BILLING_LOG_FILE
