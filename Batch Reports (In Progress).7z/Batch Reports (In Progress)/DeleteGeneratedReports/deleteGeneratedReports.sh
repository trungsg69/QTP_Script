##########################
# Reports Deletion Script.
##########################

# Use absolute path
. /home/redars/Trung_report/BatchReports/v24.1/setEnv.sh

rm -f ${OUTPUTDIR}/*.txt ${OUTPUTDIR}/*.gz && echo "Reports have been deleted.";

