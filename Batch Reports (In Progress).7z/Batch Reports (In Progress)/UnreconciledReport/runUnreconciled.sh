##############################################################################
# Unreconciled Report Script.
# This script calls several times Unreconciled application
# to generate output files in TEMPDIR directory for every problem type
# and document category.
# Then it sorts every file by doc_id, appends "End of Data" marker and places
# result files in OUTPUTDIR directory
#
# All temporary files are deleted at the end.
#
# See BatchReports Deployment Manual document for more information
#
# Last Update - 15 March 2005 for build 8.1.8
##############################################################################

# Set absolute path to the directory where Batch Reports are deployed.
BATCH_REPORTS_DIR=/home/redars/Trung_report/BatchReports/v25.1.0.01
# Set Unreconciled report file prefix here, not in command line.
UNRECONCILED_FILENAME_PREFIX=Unreconciled

# Internal parameters - Do not modify
REPORT_FILE_SUFFIX=`date +%m%d%Y`
TEMP_FILES_EXT=unrpt_tmp

. ${BATCH_REPORTS_DIR}/setEnv.sh
. ${BATCH_REPORTS_DIR}/setEnv.sh
echo Log files are located in ${LOGDIR}

# Command line for DUC_COUNT_MISMATCH problem type.
echo Generate Unreconciled Report for DUC_COUNT_MISMATCH problem type >> $UNRECONCILED_LOG_FILE
$REDARS_JAVA_HOME/bin/java -Dbatch_reports_dir=$BASEDIR -Dbatch_reports_temp_dir=$TEMPDIR -Djava.compile=NONE -classpath $REDARS_CLASSPATH com.boeing.redars.batchreport.UnreconciledReport UnreconciledReport.ProblemType=DUC_COUNT_MISMATCH GuaranteePeriod=0 >> $UNRECONCILED_LOG_FILE
cat ${TEMPDIR}/unreconciled_duc_count_mismatch_LBE.${TEMP_FILES_EXT} ${TEMPDIR}/unreconciled_duc_count_mismatch_PSE.${TEMP_FILES_EXT} ${TEMPDIR}/unreconciled_duc_count_mismatch_PST.${TEMP_FILES_EXT} ${TEMPDIR}/unreconciled_duc_count_mismatch_HCD.${TEMP_FILES_EXT} ${TEMPDIR}/unreconciled_duc_count_mismatch_SLE.${TEMP_FILES_EXT} ${TEMPDIR}/unreconciled_duc_count_mismatch_SUP.${TEMP_FILES_EXT} > ${TEMPDIR}/unreconciled_duc_count_mismatch.${TEMP_FILES_EXT}
# Sort records by doc_id and create result file
sort -T ${TEMPDIR} -o ${TEMPDIR}/unreconciled_duc_count_mismatch_sorted.${TEMP_FILES_EXT} -t~ +1 ${TEMPDIR}/unreconciled_duc_count_mismatch.${TEMP_FILES_EXT} >> $UNRECONCILED_LOG_FILE
echo "End of Data" >> ${TEMPDIR}/unreconciled_duc_count_mismatch_sorted.${TEMP_FILES_EXT}
mv ${TEMPDIR}/unreconciled_duc_count_mismatch_sorted.${TEMP_FILES_EXT} ${OUTPUTDIR}/dfhsh/${UNRECONCILED_FILENAME_PREFIX}_DUC_COUNT_MISMATCH_${REPORT_FILE_SUFFIX}.txt

# Command line for ORPHANED_ATTACHMENT problem type.
echo Generate Unreconciled Report for ORPHANED_ATTACHMENT problem type >> $UNRECONCILED_LOG_FILE
$REDARS_JAVA_HOME/bin/java -Dbatch_reports_dir=$BASEDIR -Dbatch_reports_temp_dir=$TEMPDIR -Djava.compile=NONE -classpath $REDARS_CLASSPATH com.boeing.redars.batchreport.UnreconciledReport UnreconciledReport.ProblemType=ORPHANED_ATTACHMENT GuaranteePeriod=0 >> $UNRECONCILED_LOG_FILE
cat ${TEMPDIR}/unreconciled_orp_attmnt_LBE.${TEMP_FILES_EXT} ${TEMPDIR}/unreconciled_orp_attmnt_PSE.${TEMP_FILES_EXT} ${TEMPDIR}/unreconciled_orp_attmnt_PST.${TEMP_FILES_EXT} ${TEMPDIR}/unreconciled_orp_attmnt_HCD.${TEMP_FILES_EXT} ${TEMPDIR}/unreconciled_orp_attmnt_SLE.${TEMP_FILES_EXT} ${TEMPDIR}/unreconciled_orp_attmnt_SUP.${TEMP_FILES_EXT} > ${TEMPDIR}/unreconciled_orphaned_attachment.${TEMP_FILES_EXT}
# Sort records by doc_id and create result file
sort -T ${TEMPDIR} -o ${TEMPDIR}/unreconciled_orphaned_attachment_sorted.${TEMP_FILES_EXT} -t~ +1 ${TEMPDIR}/unreconciled_orphaned_attachment.${TEMP_FILES_EXT} >> $UNRECONCILED_LOG_FILE
echo "End of Data" >> ${TEMPDIR}/unreconciled_orphaned_attachment_sorted.${TEMP_FILES_EXT}
mv ${TEMPDIR}/unreconciled_orphaned_attachment_sorted.${TEMP_FILES_EXT} ${OUTPUTDIR}/dfhsh/${UNRECONCILED_FILENAME_PREFIX}_ORPHANED_ATTACHMENT_${REPORT_FILE_SUFFIX}.txt

# Command line for CURRENCY_MISSING problem type.
echo Generate Unreconciled Report for CURRENCY_MISSING problem type >> $UNRECONCILED_LOG_FILE
$REDARS_JAVA_HOME/bin/java -Dbatch_reports_dir=$BASEDIR -Dbatch_reports_temp_dir=$TEMPDIR -Djava.compile=NONE -classpath $REDARS_CLASSPATH com.boeing.redars.batchreport.UnreconciledReport UnreconciledReport.ProblemType=CURRENCY_MISSING GuaranteePeriod=0 >> $UNRECONCILED_LOG_FILE
# Sort records by doc_id and create result file
sort -T ${TEMPDIR} -o ${TEMPDIR}/unreconciled_curr_missing_sorted.${TEMP_FILES_EXT} -t~ +1 ${TEMPDIR}/unreconciled_curr_missing.${TEMP_FILES_EXT} >> $UNRECONCILED_LOG_FILE
echo "End of Data" >> ${TEMPDIR}/unreconciled_curr_missing_sorted.${TEMP_FILES_EXT}
mv ${TEMPDIR}/unreconciled_curr_missing_sorted.${TEMP_FILES_EXT} ${OUTPUTDIR}/dfhsh/${UNRECONCILED_FILENAME_PREFIX}_CURRENCY_MISSING_${REPORT_FILE_SUFFIX}.txt

# Command line for CONTENT_DESCR_MISSING problem type.
echo Generate Unreconciled Report for CONTENT_DESCR_MISSING problem type >> $UNRECONCILED_LOG_FILE
$REDARS_JAVA_HOME/bin/java -Dbatch_reports_dir=$BASEDIR -Dbatch_reports_temp_dir=$TEMPDIR -Djava.compile=NONE -classpath $REDARS_CLASSPATH com.boeing.redars.batchreport.UnreconciledReport UnreconciledReport.ProblemType=CONTENT_DESCR_MISSING GuaranteePeriod=0 >> $UNRECONCILED_LOG_FILE
# Sort records by doc_id and create result file
sort -T ${TEMPDIR} -o ${TEMPDIR}/unreconciled_content_descr_missing_sorted.${TEMP_FILES_EXT} -t~ +1 ${TEMPDIR}/unreconciled_content_descr_missing.${TEMP_FILES_EXT} >> $UNRECONCILED_LOG_FILE
echo "End of Data" >> ${TEMPDIR}/unreconciled_content_descr_missing_sorted.${TEMP_FILES_EXT}
mv ${TEMPDIR}/unreconciled_content_descr_missing_sorted.${TEMP_FILES_EXT} ${OUTPUTDIR}/dfhsh/${UNRECONCILED_FILENAME_PREFIX}_CONTENT_DESCR_MISSING_${REPORT_FILE_SUFFIX}.txt

# Command line for ORPHANED_ENTITLEMENT problem type.
echo Generate Unreconciled Report for ORPHANED_ENTITLEMENT problem type >> $UNRECONCILED_LOG_FILE
$REDARS_JAVA_HOME/bin/java -Dbatch_reports_dir=$BASEDIR -Dbatch_reports_temp_dir=$TEMPDIR -Djava.compile=NONE -classpath $REDARS_CLASSPATH com.boeing.redars.batchreport.UnreconciledReport UnreconciledReport.ProblemType=ORPHANED_ENTITLEMENT GuaranteePeriod=0 >> $UNRECONCILED_LOG_FILE
cat ${TEMPDIR}/unreconciled_orp_entmnt_LBE.${TEMP_FILES_EXT} ${TEMPDIR}/unreconciled_orp_entmnt_PSE.${TEMP_FILES_EXT} ${TEMPDIR}/unreconciled_orp_entmnt_PST.${TEMP_FILES_EXT} ${TEMPDIR}/unreconciled_orp_entmnt_HCD.${TEMP_FILES_EXT} ${TEMPDIR}/unreconciled_orp_entmnt_SLE.${TEMP_FILES_EXT} ${TEMPDIR}/unreconciled_orp_entmnt_SUP.${TEMP_FILES_EXT} > ${TEMPDIR}/unreconciled_orphaned_entitlement.${TEMP_FILES_EXT}
# Sort records by doc_id and create result file
sort -T ${TEMPDIR} -o ${TEMPDIR}/unreconciled_orphaned_entitlement_sorted.${TEMP_FILES_EXT} -t~ +1 ${TEMPDIR}/unreconciled_orphaned_entitlement.${TEMP_FILES_EXT} >> $UNRECONCILED_LOG_FILE
echo "End of Data" >> ${TEMPDIR}/unreconciled_orphaned_entitlement_sorted.${TEMP_FILES_EXT}
mv ${TEMPDIR}/unreconciled_orphaned_entitlement_sorted.${TEMP_FILES_EXT} ${OUTPUTDIR}/dfhsh/${UNRECONCILED_FILENAME_PREFIX}_ORPHANED_ENTITLEMENT_${REPORT_FILE_SUFFIX}.txt

# Delete temporaryFiles files
. ${BATCH_REPORTS_DIR}/deleteTemporaryFiles.sh $TEMPDIR $TEMP_FILES_EXT $UNRECONCILED_LOG_FILE

echo "Unreconciled Report finished!" >> $UNRECONCILED_LOG_FILE
