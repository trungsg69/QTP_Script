########################
# Entitlement Report Script.
########################

# Use absolute path
. /home/redars/trungnguyen/BatchReports/v26.5/setEnv.sh

$REDARS_JAVA_HOME/bin/java -Dbatch_reports_dir=$BASEDIR -classpath $REDARS_CLASSPATH -Xmx1024m com.boeing.redars.batchreport.utility.BatchReportLauncher -mode ENTITLEMENTREPORT  -GUARANTEEPERIOD 0 -l $ENTITLEMENT_LOG_FILE $@
