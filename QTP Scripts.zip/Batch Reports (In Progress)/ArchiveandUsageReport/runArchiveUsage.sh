########################
# ArchiveUsage Report Script.
########################

# Use absolute path
. /home/redars/Trung_report/BatchReports/v24.1/setEnv.sh

$REDARS_JAVA_HOME/bin/java -Dbatch_reports_dir=$BASEDIR -classpath $REDARS_CLASSPATH  com.boeing.redars.batchreport.ArchiveUsageReport ArchiveUsageReport.Filename=${OUTPUTDIR}/archive_usage_  GuaranteePeriod=0  >> $ARCHIVEUSAGE_LOG_FILE
