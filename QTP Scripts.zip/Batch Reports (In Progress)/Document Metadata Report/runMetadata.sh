#!/usr/bin/ksh
##############################################################################
# Metadata Report Script.
# This script calls several times Metadata application
# to generate output files in OUTPUTDIR directory for every document category.
# Then it sorts every file by doc_id, appends "End of Data" marker and places
# result files
# Besides this, Storage report is generated for every document category.
#
# All temporary files are deleted before and after execution.
#
# See BatchReports Deployment Manual document for more information
#
# Last Update - 30 December 2006 for build 11.2.0.5
##############################################################################

# Set absolute path to the directory where Batch Reports are deployed.
BATCH_REPORTS_DIR=/home/redars/Trung_report/BatchReports/v25.1.0.01
# Set Metadata report file prefix here, not in command line.
METADATA_FILENAME_PREFIX=Metadata
# Set Storage report file prefix here, not in command line.
STORAGE_FILENAME_PREFIX=Storage
# Set POSIX locale to suppress the known bug in sort utility
LANG=c

# Internal parameters - Do not modify
TEMP_FILES_EXT=mdrpt_tmp

# Call setEnv.sh
. ${BATCH_REPORTS_DIR}/setEnv.sh

if [ $# -lt 1 ] ; then

REPORT_FILE_SUFFIX=`date +%m%d%Y`
echo Log files are located in ${LOGDIR}

# Delete temporaryFiles files
. ${BATCH_REPORTS_DIR}/deleteTemporaryFiles.sh $TEMPDIR $TEMP_FILES_EXT $METADATA_LOG_FILE
rm -f $METADATA_LOG_FILE.PSE $METADATA_LOG_FILE.PST $METADATA_LOG_FILE.HCD $METADATA_LOG_FILE.LBE $METADATA_LOG_FILE.SLE $METADATA_LOG_FILE.SUP

else

if [ $# -ne 3 ] ; then

	echo Error: runMetadata.sh should be run without parameters!
	exit 1

fi

case $1 in

	PSE)	# Command line for PSE category.
		echo Generate Metadata Report for PSE category >> $METADATA_LOG_FILE.PSE
		$REDARS_JAVA_HOME/bin/java -Dbatch_reports_dir=$BASEDIR -Dbatch_reports_temp_dir=$TEMPDIR -Djava.compile=NONE -classpath $REDARS_CLASSPATH com.boeing.redars.batchreport.MetadataReport MetadataReport.DocumentCategory=PSE GuaranteePeriod=-1 >> $METADATA_LOG_FILE.PSE
		# Sort records by doc_id and create result file
		sort -T ${TEMPDIR} -o ${TEMPDIR}/Metadata_PSE_$3.${TEMP_FILES_EXT} -t~ +1 ${TEMPDIR}/metadata_PSE.${TEMP_FILES_EXT} >> $METADATA_LOG_FILE.PSE
		cat ${TEMPDIR}/Metadata_PSE_$3.${TEMP_FILES_EXT} ${TEMPDIR}/end_footer.${TEMP_FILES_EXT} > ${OUTPUTDIR}/${METADATA_FILENAME_PREFIX}_PSE_$3.txt
		sleep 1
		rm $BATCH_REPORTS_DIR/busy_PSE.$2
		exit 0
		;;

	PST)	# Command line for PST category.
		echo Generate Metadata Report for PST category >> $METADATA_LOG_FILE.PST
		$REDARS_JAVA_HOME/bin/java -Dbatch_reports_dir=$BASEDIR -Dbatch_reports_temp_dir=$TEMPDIR -Djava.compile=NONE -classpath $REDARS_CLASSPATH com.boeing.redars.batchreport.MetadataReport MetadataReport.DocumentCategory=PST GuaranteePeriod=-1 >> $METADATA_LOG_FILE.PST
		# Sort records by doc_id and create result file
		sort -T ${TEMPDIR} -o ${TEMPDIR}/Metadata_PST_$3.${TEMP_FILES_EXT} -t~ +1 ${TEMPDIR}/metadata_PST.${TEMP_FILES_EXT} >> $METADATA_LOG_FILE.PST
		cat ${TEMPDIR}/Metadata_PST_$3.${TEMP_FILES_EXT} ${TEMPDIR}/end_footer.${TEMP_FILES_EXT} > ${OUTPUTDIR}/${METADATA_FILENAME_PREFIX}_PST_$3.txt
		sleep 1
		rm $BATCH_REPORTS_DIR/busy_PST.$2
		exit 0
		;;

	HCD)	# Command line for HCD category.
		echo Generate Metadata Report for HCD category >> $METADATA_LOG_FILE.HCD
		$REDARS_JAVA_HOME/bin/java -Dbatch_reports_dir=$BASEDIR -Dbatch_reports_temp_dir=$TEMPDIR -Djava.compile=NONE -classpath $REDARS_CLASSPATH com.boeing.redars.batchreport.MetadataReport MetadataReport.DocumentCategory=HCD GuaranteePeriod=-1 >> $METADATA_LOG_FILE.HCD
		# Sort records by doc_id and create result file
		sort -T ${TEMPDIR} -o ${TEMPDIR}/Metadata_HCD_$3.${TEMP_FILES_EXT} -t~ +1 ${TEMPDIR}/metadata_HCD.${TEMP_FILES_EXT} >> $METADATA_LOG_FILE.HCD
		cat ${TEMPDIR}/Metadata_HCD_$3.${TEMP_FILES_EXT} ${TEMPDIR}/end_footer.${TEMP_FILES_EXT} > ${OUTPUTDIR}/${METADATA_FILENAME_PREFIX}_HCD_$3.txt
		sleep 1
		rm $BATCH_REPORTS_DIR/busy_HCD.$2
		exit 0
		;;

	LBE)	# Command line for LBE category.
		echo Generate Metadata Report for LBE category >> $METADATA_LOG_FILE.LBE
		$REDARS_JAVA_HOME/bin/java -Dbatch_reports_dir=$BASEDIR -Dbatch_reports_temp_dir=$TEMPDIR -Djava.compile=NONE -classpath $REDARS_CLASSPATH com.boeing.redars.batchreport.MetadataReport MetadataReport.DocumentCategory=LBE GuaranteePeriod=-1 >> $METADATA_LOG_FILE.LBE
		# Sort records by doc_id and create result file
		sort -T ${TEMPDIR} -o ${TEMPDIR}/Metadata_LBE_$3.${TEMP_FILES_EXT} -t~ +1 ${TEMPDIR}/metadata_LBE.${TEMP_FILES_EXT} >> $METADATA_LOG_FILE.LBE
		cat ${TEMPDIR}/Metadata_LBE_$3.${TEMP_FILES_EXT} ${TEMPDIR}/end_footer.${TEMP_FILES_EXT} > ${OUTPUTDIR}/${METADATA_FILENAME_PREFIX}_LBE_$3.txt
		sleep 1
		rm $BATCH_REPORTS_DIR/busy_LBE.$2
		exit 0
		;;

	SLE)	# Command line for SLE category.
		echo Generate Metadata Report for SLE category >> $METADATA_LOG_FILE.SLE
		$REDARS_JAVA_HOME/bin/java -Dbatch_reports_dir=$BASEDIR -Dbatch_reports_temp_dir=$TEMPDIR -Djava.compile=NONE -classpath $REDARS_CLASSPATH com.boeing.redars.batchreport.MetadataReport MetadataReport.DocumentCategory=SLE GuaranteePeriod=-1 >> $METADATA_LOG_FILE.SLE
		# Sort records by doc_id and create result file
		sort -T ${TEMPDIR} -o ${TEMPDIR}/Metadata_SLE_$3.${TEMP_FILES_EXT} -t~ +1 ${TEMPDIR}/metadata_SLE.${TEMP_FILES_EXT} >> $METADATA_LOG_FILE.SLE
		cat ${TEMPDIR}/Metadata_SLE_$3.${TEMP_FILES_EXT} ${TEMPDIR}/end_footer.${TEMP_FILES_EXT} > ${OUTPUTDIR}/${METADATA_FILENAME_PREFIX}_SLE_$3.txt
		sleep 1
		rm $BATCH_REPORTS_DIR/busy_SLE.$2
		exit 0
		;;

	SUP)	# Command line for SUP category.
		echo Generate Metadata Report for SUP category >> $METADATA_LOG_FILE.SUP
		$REDARS_JAVA_HOME/bin/java -Dbatch_reports_dir=$BASEDIR -Dbatch_reports_temp_dir=$TEMPDIR -Djava.compile=NONE -classpath $REDARS_CLASSPATH com.boeing.redars.batchreport.MetadataReport MetadataReport.DocumentCategory=SUP GuaranteePeriod=-1 >> $METADATA_LOG_FILE.SUP
		# Sort records by doc_id and create result file
		sort -T ${TEMPDIR} -o ${TEMPDIR}/Metadata_SUP_$3.${TEMP_FILES_EXT} -t~ +1 ${TEMPDIR}/metadata_SUP.${TEMP_FILES_EXT} >> $METADATA_LOG_FILE.SUP
		cat ${TEMPDIR}/Metadata_SUP_$3.${TEMP_FILES_EXT} ${TEMPDIR}/end_footer.${TEMP_FILES_EXT} > ${OUTPUTDIR}/${METADATA_FILENAME_PREFIX}_SUP_$3.txt
		sleep 1
		rm $BATCH_REPORTS_DIR/busy_SUP.$2
		exit 0
		;;

	*)	. ${BATCH_REPORTS_DIR}/deleteTemporaryFiles.sh $TEMPDIR $TEMP_FILES_EXT $METADATA_LOG_FILE
		rm -f $METADATA_LOG_FILE.* $BATCH_REPORTS_DIR/busy_???.$$
		exit 1
		;;

esac

fi
rm -f ${TEMPDIR}/header_flag.${TEMP_FILES_EXT}

touch $BATCH_REPORTS_DIR/busy_PSE.$$
touch $BATCH_REPORTS_DIR/busy_PST.$$
touch $BATCH_REPORTS_DIR/busy_HCD.$$
touch $BATCH_REPORTS_DIR/busy_LBE.$$
touch $BATCH_REPORTS_DIR/busy_SLE.$$
touch $BATCH_REPORTS_DIR/busy_SUP.$$

# Run reports in parallel
. $0 PSE $$ $REPORT_FILE_SUFFIX &
. $0 PST $$ $REPORT_FILE_SUFFIX &
. $0 HCD $$ $REPORT_FILE_SUFFIX &
. $0 LBE $$ $REPORT_FILE_SUFFIX &
. $0 SLE $$ $REPORT_FILE_SUFFIX &
. $0 SUP $$ $REPORT_FILE_SUFFIX &

# Wait util all subreports are terminated
sleep 2
while [ -f $BATCH_REPORTS_DIR/busy_PSE.$$ \
	-o -f $BATCH_REPORTS_DIR/busy_PST.$$ \
	-o -f $BATCH_REPORTS_DIR/busy_HCD.$$ \
	-o -f $BATCH_REPORTS_DIR/busy_LBE.$$ \
	-o -f $BATCH_REPORTS_DIR/busy_SLE.$$ \
	-o -f $BATCH_REPORTS_DIR/busy_SUP.$$ ]; do
sleep 2
done

# Create whole log file
cat $METADATA_LOG_FILE.PSE $METADATA_LOG_FILE.PST $METADATA_LOG_FILE.HCD $METADATA_LOG_FILE.LBE $METADATA_LOG_FILE.SLE $METADATA_LOG_FILE.SUP >> $METADATA_LOG_FILE

# Creating Storage report from temporary files.
# Do not modify this section.
echo "Create Storage report." >> $METADATA_LOG_FILE
cat ${TEMPDIR}/storage_header.${TEMP_FILES_EXT} ${TEMPDIR}/storage_PSE.${TEMP_FILES_EXT} ${TEMPDIR}/storage_PST.${TEMP_FILES_EXT} ${TEMPDIR}/storage_HCD.${TEMP_FILES_EXT} ${TEMPDIR}/storage_LBE.${TEMP_FILES_EXT} ${TEMPDIR}/storage_SLE.${TEMP_FILES_EXT} ${TEMPDIR}/storage_SUP.${TEMP_FILES_EXT} ${TEMPDIR}/end_footer.${TEMP_FILES_EXT} > ${OUTPUTDIR}/${STORAGE_FILENAME_PREFIX}_All_${REPORT_FILE_SUFFIX}.txt

# Delete temporaryFiles files
. ${BATCH_REPORTS_DIR}/deleteTemporaryFiles.sh $TEMPDIR $TEMP_FILES_EXT $METADATA_LOG_FILE
rm -f $METADATA_LOG_FILE.PSE $METADATA_LOG_FILE.PST $METADATA_LOG_FILE.HCD $METADATA_LOG_FILE.LBE $METADATA_LOG_FILE.SLE $METADATA_LOG_FILE.SUP $BATCH_REPORTS_DIR/busy_???.$$

echo "Metadata & Storage Report finished!" >> $METADATA_LOG_FILE

exit 0
