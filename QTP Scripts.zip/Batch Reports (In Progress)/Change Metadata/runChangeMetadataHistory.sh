########################
# Change Metadata History Report Script.
########################

# Use absolute path to Batch Reports environment config
. /home/redars/Trung_report/BatchReports/v25.1.0.01/setEnv.sh

# Please set appropriate guarantee period or override it
# using "GuaranteePeriod" command line parameter
GUARANTEE_PERIOD=0

# Please set appropriate filename path or override it
# using parameter "changeMetadataHistoryReport.reportFileName"
REPORT_FILENAME=${OUTPUTDIR}/changeMetadataHistory

# Please do not change/remove this variable
MAIN_CLASS=com.boeing.redars.batchreport.ChangeMetadataHistoryReport

$REDARS_JAVA_HOME/bin/java -Dbatch_reports_dir=${BASEDIR} -classpath ${REDARS_CLASSPATH} ${MAIN_CLASS} GuaranteePeriod=${GUARANTEE_PERIOD} changeMetadataHistoryReport.reportFileName=${REPORT_FILENAME} $* >> $CHANGE_METADATA_HISTORY_LOG_FILE 2>&1
