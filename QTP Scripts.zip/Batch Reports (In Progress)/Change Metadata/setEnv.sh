#########################################
# Batch Reports environment setup script.
#########################################

# Directory, where BatchReports are installed
BASEDIR=/home/redars/Trung_report/BatchReports/v25.1.0.01
# Directory for temporary files
TEMPDIR=$BASEDIR/temp
# Output directory for generated reports
OUTPUTDIR=${BASEDIR}/output
# Output directory for logs
LOGDIR=${BASEDIR}/logs
# Log file for redirecting Unreconciled Report's messages
UNRECONCILED_LOG_FILE=${LOGDIR}/unreconciled_report.out
# Log file for redirecting Billing Report's messages
BILLING_LOG_FILE=${LOGDIR}/billing_report.out
# Log file for redirecting Metadata Report's messages
METADATA_LOG_FILE=${LOGDIR}/metadata_report.out
# Log file for redirecting Archive and Usage Report's messages
ARCHIVEUSAGE_LOG_FILE=${LOGDIR}/archiveusage_report.out
# Log file for redirecting Entitlement Report's messages
ENTITLEMENT_LOG_FILE=${LOGDIR}/entitlement_report.out
# Log file for redirecting Compare File Size Report's messages
FILE_SIZE_LOG_FILE=${LOGDIR}/filesize_report.out
# Log file for redirecting Change Metadata History Report's messages
CHANGE_METADATA_HISTORY_LOG_FILE=${LOGDIR}/changemetadatahistory_report.out
# Log file for redirecting ExportMismatch Report's messages
EXPORTMISMATCH_LOG_FILE=${LOGDIR}/exportmismatch_report.out

# Set environment's paths
REDARS_JAVA_HOME=/usr/IBM/WebSphere/AppServer/java
REDARS_LIB_PATH=$BASEDIR/lib
REDARS_CLASSPATH=$REDARS_LIB_PATH/mail.jar:$REDARS_LIB_PATH/activation.jar:$REDARS_LIB_PATH/batchreport.jar:$REDARS_LIB_PATH/redars_base_utility.jar:$REDARS_LIB_PATH/db2jcc.jar:$REDARS_LIB_PATH/db2jcc_license_cu.jar:$REDARS_LIB_PATH/jdom.jar:$REDARS_LIB_PATH/xercesImpl.jar:$REDARS_LIB_PATH/xml-apis.jar:$REDARS_LIB_PATH/commons-cli-1.0.jar:$REDARS_LIB_PATH/commons-collections-3.1.jar:$REDARS_LIB_PATH/commons-dbcp-1.2.1.jar:$REDARS_LIB_PATH/commons-pool-1.2.jar:$REDARS_LIB_PATH/soap2_3_1.jar:$REDARS_LIB_PATH/log4j-1.2.5.jar:

export BASEDIR TEMPDIR OUTPUTDIR LOGDIR UNRECONCILED_LOG_FILE BILLING_LOG_FILE METADATA_LOG_FILE ARCHIVEUSAGE_LOG_FILE ENTITLEMENT_LOG_FILE FILE_SIZE_LOG_FILE CHANGE_METADATA_HISTORY_LOG_FILE REDARS_JAVA_HOME REDARS_LIB_PATH PATH REDARS_CLASSPATH
