runChangeMetadataHistory.sh - file to edit and replace with the same .sh on server

output - folder for report output files

Script.scr - script file for ftp.exe to perform file operations via FTP

bat.bat - executable file to run Script.scr

defaultSetting.xml - draft Batch Reports config file

runChangeMetadataHistory.sh - draft executable file to run Change Metadata History Report