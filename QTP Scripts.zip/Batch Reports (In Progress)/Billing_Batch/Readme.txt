# ========== User guide of View_Overlay script ========== #

I. Data pool information:

 1. Global sheet: global information
   + sPathTo_psftp: Path to psftp.exe file
   + sPathTo_putty: Path to putty.exe file
   + shName: name of SH file

 2. Putty sheet: information of accounts which are used to login server by SSH by Putty.
   + URL: hostname of server
   + Login: Username is used to login server by Putty
   + Pwd: Password is used to login server by Putty
   + Path: Path to working folder in server
   + DoneText: Symbol is used to recognize end of command
   + JavaHome: Path to Java folder in server.
   + RunLine: line number is selected of Putty sheet.

3. Start and Finish Dates sheet:
   + ReportDateBegin: Begin date is used to get in report
   + ReportDateFinish: Finish date is used to get in report
   + MessageText: Message is checked by script when error occurs.

4. Check_OutputFile
   + ReportDateBegin: Begin date is used to get in report
   + ReportDateFinish: Finish date is used to get in report
   + Prefix: Prexi of file name (output file)
   + EndOfFileSymbol: String is end of file

5. Check_PrintTransactions
   + TransactionType: Name of transaction type
   + SQL: Sql query is used to get data from DB
   + FromDate: Begin date is used to get data in DB
   +ToDate: Finish date is used to get data in DB

II. How to run script:

   + Set values in Global sheet:
	- sPathTo_psftp: Set path to psftp.exe file
	- sPathTo_putty: Set path to putty.exe file
	- shName: Set name of SH file

   + Set values in Putty sheet:
      - Runline: Select the line number will be run in Putty sheet.

   + Run script from QTP
