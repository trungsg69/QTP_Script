###############################
# ExportMismatch Report Script.
###############################

# Use absolute path
. /home/redars/Trung_report/BatchReports/v25.1.0.01/setEnv.sh

$REDARS_JAVA_HOME/bin/java -Dbatch_reports_dir=$BASEDIR -classpath $REDARS_CLASSPATH com.boeing.redars.batchreport.utility.BatchReportLauncher -mode EXPORTMISMATCHREPORT -l $EXPORTMISMATCH_LOG_FILE $@
